"use client"

import { notFound } from "next/navigation"
import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import ImageGallery from "@/components/image-gallery"
import PropertyShare from "@/components/property-share"
import InquiryForm from "@/components/inquiry-form"
import { getPropertyById, getCompanyInfo } from "@/lib/properties"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import {
  MapPin,
  Bed,
  Bath,
  Maximize,
  Building,
  Calendar,
  CheckCircle,
  Phone,
  MessageCircle,
  ArrowLeft,
  Printer,
} from "lucide-react"
import Link from "next/link"

interface PropertyPageProps {
  params: { id: string }
}

export default function PropertyPageClient({ params }: PropertyPageProps) {
  const { id } = params
  const property = getPropertyById(Number.parseInt(id))
  const companyInfo = getCompanyInfo()

  if (!property) {
    notFound()
  }

  const whatsappMessage = `مرحباً، أرغب في الاستفسار عن العقار: ${property.title} - ${property.location}`
  const whatsappUrl = `https://wa.me/${companyInfo.whatsapp.replace("+", "")}?text=${encodeURIComponent(whatsappMessage)}`

  return (
    <main className="min-h-screen bg-background" dir="rtl">
      <Header />

      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Breadcrumb & Actions */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2 text-sm text-gray">
              <Link href="/" className="hover:text-gold transition-colors">
                الرئيسية
              </Link>
              <span>/</span>
              <Link href="/properties" className="hover:text-gold transition-colors">
                العقارات
              </Link>
              <span>/</span>
              <span className="text-charcoal">{property.title}</span>
            </div>
            <div className="flex items-center gap-2">
              <PropertyShare title={property.title} url={`/properties/${property.id}`} />
              <Button
                variant="outline"
                size="sm"
                className="gap-2 bg-transparent"
                onClick={() => typeof window !== "undefined" && window.print()}
              >
                <Printer className="h-4 w-4" />
                طباعة
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Image Gallery */}
              <ImageGallery images={property.images} title={property.title} />

              {/* Property Info */}
              <div className="space-y-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={property.type === "بيع" ? "bg-gold text-charcoal" : "bg-green text-white"}>
                        {property.type}
                      </Badge>
                      <Badge variant="outline">{property.category}</Badge>
                      {property.status === "متاح" && (
                        <Badge className="bg-green/10 text-green border-green/20">
                          <CheckCircle className="h-3 w-3 ml-1" />
                          متاح
                        </Badge>
                      )}
                    </div>
                    <h1 className="text-3xl font-bold text-charcoal mb-2">{property.title}</h1>
                    <p className="flex items-center gap-2 text-gray">
                      <MapPin className="h-5 w-5 text-gold" />
                      {property.location}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-sm text-gray">السعر</p>
                    <p className="text-3xl font-bold text-gold">{property.price}</p>
                    <p className="text-sm text-gray">{property.priceType}</p>
                  </div>
                </div>

                {/* Quick Stats */}
                <Card className="border-gold/20">
                  <CardContent className="p-6">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                      <div className="text-center">
                        <Maximize className="h-6 w-6 text-gold mx-auto mb-2" />
                        <p className="text-2xl font-bold text-charcoal">{property.area}</p>
                        <p className="text-sm text-gray">متر مربع</p>
                      </div>
                      {property.bedrooms > 0 && (
                        <div className="text-center">
                          <Bed className="h-6 w-6 text-gold mx-auto mb-2" />
                          <p className="text-2xl font-bold text-charcoal">{property.bedrooms}</p>
                          <p className="text-sm text-gray">غرف نوم</p>
                        </div>
                      )}
                      {property.bathrooms > 0 && (
                        <div className="text-center">
                          <Bath className="h-6 w-6 text-gold mx-auto mb-2" />
                          <p className="text-2xl font-bold text-charcoal">{property.bathrooms}</p>
                          <p className="text-sm text-gray">حمامات</p>
                        </div>
                      )}
                      {property.floor > 0 && (
                        <div className="text-center">
                          <Building className="h-6 w-6 text-gold mx-auto mb-2" />
                          <p className="text-2xl font-bold text-charcoal">{property.floor}</p>
                          <p className="text-sm text-gray">الطابق</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Description */}
                <div>
                  <h2 className="text-xl font-bold text-charcoal mb-4">وصف العقار</h2>
                  <p className="text-gray leading-relaxed">{property.description}</p>
                </div>

                {/* Features */}
                <div>
                  <h2 className="text-xl font-bold text-charcoal mb-4">مميزات العقار</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {property.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 p-3 bg-beige-dark rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green flex-shrink-0" />
                        <span className="text-charcoal">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Details */}
                <div>
                  <h2 className="text-xl font-bold text-charcoal mb-4">تفاصيل إضافية</h2>
                  <div className="grid grid-cols-2 gap-4">
                    {property.yearBuilt > 0 && (
                      <div className="flex items-center gap-3 p-4 bg-beige-dark rounded-lg">
                        <Calendar className="h-5 w-5 text-gold" />
                        <div>
                          <p className="text-sm text-gray">سنة البناء</p>
                          <p className="font-bold text-charcoal">{property.yearBuilt}</p>
                        </div>
                      </div>
                    )}
                    {property.totalFloors > 0 && (
                      <div className="flex items-center gap-3 p-4 bg-beige-dark rounded-lg">
                        <Building className="h-5 w-5 text-gold" />
                        <div>
                          <p className="text-sm text-gray">إجمالي الطوابق</p>
                          <p className="font-bold text-charcoal">{property.totalFloors}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Card */}
              <Card className="border-gold/20 sticky top-24">
                <CardContent className="p-6 space-y-4">
                  <h3 className="text-xl font-bold text-charcoal">تواصل معنا</h3>
                  <p className="text-gray text-sm">
                    مهتم بهذا العقار؟ تواصل معنا الآن للمزيد من المعلومات أو لترتيب معاينة
                  </p>
                  <div className="space-y-3">
                    <Button asChild className="w-full bg-green hover:bg-green-light text-white gap-2 h-12">
                      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                        <MessageCircle className="h-5 w-5" />
                        تواصل عبر واتساب
                      </a>
                    </Button>
                    <Button
                      asChild
                      variant="outline"
                      className="w-full border-gold text-gold hover:bg-gold hover:text-charcoal gap-2 h-12 bg-transparent"
                    >
                      <a href={`tel:${companyInfo.phone}`}>
                        <Phone className="h-5 w-5" />
                        اتصل الآن
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Inquiry Form */}
              <InquiryForm propertyTitle={property.title} propertyId={property.id} />
            </div>
          </div>

          {/* Back Button */}
          <div className="mt-12">
            <Button asChild variant="outline" className="gap-2 bg-transparent">
              <Link href="/properties">
                <ArrowLeft className="h-4 w-4" />
                العودة للعقارات
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppButton />

      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "RealEstateListing",
            name: property.title,
            description: property.description,
            image: property.images,
            url: `https://ghanam-realestate.com/properties/${property.id}`,
            address: {
              "@type": "PostalAddress",
              addressLocality: "المحلة الكبرى",
              addressRegion: "الغربية",
              addressCountry: "EG",
              streetAddress: property.location,
            },
            price: property.price.replace(/,/g, ""),
            priceCurrency: "EGP",
            floorSize: {
              "@type": "QuantitativeValue",
              value: property.area,
              unitCode: "MTK",
            },
            numberOfRooms: property.bedrooms,
            numberOfBathroomsTotal: property.bathrooms,
          }),
        }}
      />
    </main>
  )
}
