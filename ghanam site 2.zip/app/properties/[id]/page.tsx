import { notFound } from "next/navigation"
import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import PropertyDetailContent from "@/components/property-detail-content"
import { getPropertyById, getSimilarProperties } from "@/lib/supabase/properties"

interface PropertyPageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PropertyPageProps): Promise<Metadata> {
  const { id } = await params
  const property = await getPropertyById(Number.parseInt(id))

  if (!property) {
    return {
      title: "عقار غير موجود | غنّام للعقارات",
    }
  }

  return {
    title: `${property.title} | غنّام للعقارات`,
    description: property.description,
    openGraph: {
      title: property.title,
      description: property.description || "",
      images: property.images[0] ? [property.images[0]] : [],
    },
  }
}

export default async function PropertyPage({ params }: PropertyPageProps) {
  const { id } = await params
  const property = await getPropertyById(Number.parseInt(id))

  if (!property) {
    notFound()
  }

  const similarProperties = await getSimilarProperties(property, 3)

  return (
    <main className="min-h-screen bg-background" dir="rtl">
      <Header />
      <PropertyDetailContent property={property} similarProperties={similarProperties} />
      <Footer />
      <WhatsAppButton />

      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "RealEstateListing",
            name: property.title,
            description: property.description,
            image: property.images,
            url: `https://ghanam-realestate.com/properties/${property.id}`,
            address: {
              "@type": "PostalAddress",
              addressLocality: "المحلة الكبرى",
              addressRegion: "الغربية",
              addressCountry: "EG",
              streetAddress: property.location,
            },
            price: property.price,
            priceCurrency: "EGP",
            floorSize: {
              "@type": "QuantitativeValue",
              value: property.area,
              unitCode: "MTK",
            },
            numberOfRooms: property.bedrooms,
            numberOfBathroomsTotal: property.bathrooms,
          }),
        }}
      />
    </main>
  )
}
