import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import PropertiesPageContent from "@/components/properties-page-content"
import { getProperties } from "@/lib/supabase/properties"
import type { PropertyFilters } from "@/lib/supabase/types"

export const metadata = {
  title: "العقارات المتاحة | غنّام للعقارات",
  description: "تصفح جميع العقارات المتاحة للبيع والإيجار في المحلة الكبرى - شقق، فيلات، محلات تجارية، أراضي",
}

interface PropertiesPageProps {
  searchParams: Promise<{
    search?: string
    type?: string
    category?: string
    bedrooms?: string
    minPrice?: string
    maxPrice?: string
    minArea?: string
    maxArea?: string
    sortBy?: string
  }>
}

export default async function PropertiesPage({ searchParams }: PropertiesPageProps) {
  const params = await searchParams

  const filters: PropertyFilters = {
    search: params.search,
    type: params.type,
    category: params.category,
    bedrooms: params.bedrooms,
    minPrice: params.minPrice ? Number(params.minPrice) : undefined,
    maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
    minArea: params.minArea ? Number(params.minArea) : undefined,
    maxArea: params.maxArea ? Number(params.maxArea) : undefined,
    sortBy: (params.sortBy as PropertyFilters["sortBy"]) || "newest",
  }

  // Fetch properties from Supabase with filters
  const properties = await getProperties(filters)

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <PropertiesPageContent initialProperties={properties} />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
