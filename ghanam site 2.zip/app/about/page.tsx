import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import AboutPageContent from "@/components/about-page-content"

export const metadata = {
  title: "من نحن | غنّام للعقارات",
  description: "تعرف على غنّام للعقارات - شريكك الموثوق في سوق العقارات بالمحلة الكبرى منذ أكثر من 15 عاماً",
}

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <AboutPageContent />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
