import { createClient } from "@/lib/supabase/server"
import { AdminInquiriesList } from "@/components/admin/admin-inquiries-list"

export default async function AdminInquiriesPage() {
  const supabase = await createClient()

  const { data: inquiries, error } = await supabase
    .from("inquiries")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching inquiries:", error)
  }

  return <AdminInquiriesList inquiries={inquiries || []} />
}
