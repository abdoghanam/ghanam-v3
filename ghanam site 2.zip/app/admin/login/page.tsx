import { AdminLoginForm } from "@/components/admin/admin-login-form"

export const metadata = {
  title: "تسجيل الدخول | لوحة التحكم",
  description: "تسجيل الدخول إلى لوحة تحكم غنام للعقارات",
}

export default function AdminLoginPage() {
  return (
    <div
      className="min-h-screen flex items-center justify-center bg-gradient-to-br from-charcoal via-charcoal-light to-charcoal p-4"
      dir="rtl"
    >
      <div className="w-full max-w-md">
        {/* Logo & Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-gold to-gold-dark mb-4 shadow-lg">
            <svg className="w-10 h-10 text-charcoal" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
              />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-beige mb-2">غنام للعقارات</h1>
          <p className="text-gray">لوحة التحكم الإدارية</p>
        </div>

        {/* Login Card */}
        <div className="bg-card rounded-2xl shadow-2xl p-8 border border-border/50">
          <h2 className="text-xl font-semibold text-foreground mb-6 text-center">تسجيل الدخول</h2>
          <AdminLoginForm />
        </div>

        {/* Footer */}
        <p className="text-center text-gray text-sm mt-6">
          © {new Date().getFullYear()} غنام للعقارات. جميع الحقوق محفوظة
        </p>
      </div>
    </div>
  )
}
