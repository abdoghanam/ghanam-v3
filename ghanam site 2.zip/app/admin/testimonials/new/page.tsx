import { AdminTestimonialForm } from "@/components/admin/admin-testimonial-form"

export default function NewTestimonialPage() {
  return <AdminTestimonialForm />
}
