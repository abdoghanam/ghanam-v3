import { createClient } from "@/lib/supabase/server"
import { AdminTestimonialsList } from "@/components/admin/admin-testimonials-list"

export default async function AdminTestimonialsPage() {
  const supabase = await createClient()

  const { data: testimonials, error } = await supabase
    .from("testimonials")
    .select("*")
    .order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching testimonials:", error)
  }

  return <AdminTestimonialsList testimonials={testimonials || []} />
}
