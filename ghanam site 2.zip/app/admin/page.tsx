import { createClient } from "@/lib/supabase/server"
import { AdminDashboardContent } from "@/components/admin/admin-dashboard-content"

export default async function AdminDashboardPage() {
  const supabase = await createClient()

  // Fetch dashboard statistics
  const [propertiesRes, inquiriesRes, newInquiriesRes] = await Promise.all([
    supabase.from("properties").select("id, type, category, status", { count: "exact" }),
    supabase.from("inquiries").select("*", { count: "exact" }).order("created_at", { ascending: false }).limit(5),
    supabase.from("inquiries").select("id", { count: "exact" }).eq("status", "جديد"),
  ])

  const properties = propertiesRes.data || []
  const totalProperties = propertiesRes.count || 0
  const recentInquiries = inquiriesRes.data || []
  const totalInquiries = inquiriesRes.count || 0
  const newInquiriesCount = newInquiriesRes.count || 0

  // Calculate stats
  const availableProperties = properties.filter((p) => p.status === "متاح").length
  const soldProperties = properties.filter((p) => p.status === "مباع").length
  const rentedProperties = properties.filter((p) => p.type === "إيجار").length

  // Group by type and category
  const propertiesByType = [
    { type: "بيع", count: properties.filter((p) => p.type === "بيع").length },
    { type: "إيجار", count: properties.filter((p) => p.type === "إيجار").length },
    { type: "بدل", count: properties.filter((p) => p.type === "بدل").length },
  ]

  const propertiesByCategory = [
    { category: "شقة", count: properties.filter((p) => p.category === "شقة").length },
    { category: "فيلا", count: properties.filter((p) => p.category === "فيلا").length },
    { category: "تجاري", count: properties.filter((p) => p.category === "تجاري").length },
    { category: "أرض", count: properties.filter((p) => p.category === "أرض").length },
    { category: "مكتب", count: properties.filter((p) => p.category === "مكتب").length },
  ]

  const stats = {
    totalProperties,
    availableProperties,
    soldProperties,
    rentedProperties,
    totalInquiries,
    newInquiries: newInquiriesCount,
    totalViews: 0,
    recentInquiries,
    propertiesByType,
    propertiesByCategory,
    monthlyInquiries: [],
  }

  return <AdminDashboardContent stats={stats} />
}
