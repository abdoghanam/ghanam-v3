import { createClient } from "@/lib/supabase/server"
import { AdminSettingsForm } from "@/components/admin/admin-settings-form"

export const metadata = {
  title: "الإعدادات | لوحة التحكم",
  description: "إعدادات موقع غنام للعقارات",
}

export default async function AdminSettingsPage() {
  const supabase = await createClient()

  const { data: settings } = await supabase.from("site_settings").select("*").order("category")

  // Transform to key-value object
  const settingsMap: Record<string, string> = {}
  settings?.forEach((s) => {
    settingsMap[s.key] = s.value || ""
  })

  return <AdminSettingsForm settings={settingsMap} />
}
