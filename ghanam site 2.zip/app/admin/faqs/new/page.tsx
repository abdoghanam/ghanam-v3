import { AdminFaqForm } from "@/components/admin/admin-faq-form"

export default function NewFaqPage() {
  return <AdminFaqForm />
}
