import { createClient } from "@/lib/supabase/server"
import { AdminFaqForm } from "@/components/admin/admin-faq-form"
import { notFound } from "next/navigation"

export default async function EditFaqPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()

  const { data: faq, error } = await supabase.from("faqs").select("*").eq("id", id).single()

  if (error || !faq) {
    notFound()
  }

  return <AdminFaqForm faq={faq} />
}
