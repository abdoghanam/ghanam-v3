import { createClient } from "@/lib/supabase/server"
import { AdminFaqsList } from "@/components/admin/admin-faqs-list"

export default async function AdminFaqsPage() {
  const supabase = await createClient()

  const { data: faqs, error } = await supabase.from("faqs").select("*").order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching faqs:", error)
  }

  return <AdminFaqsList faqs={faqs || []} />
}
