import { createClient } from "@/lib/supabase/server"
import { AdminPropertyForm } from "@/components/admin/admin-property-form"
import { notFound } from "next/navigation"

export default async function EditPropertyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()

  const { data: property, error } = await supabase.from("properties").select("*").eq("id", id).single()

  if (error || !property) {
    notFound()
  }

  return <AdminPropertyForm property={property} />
}
