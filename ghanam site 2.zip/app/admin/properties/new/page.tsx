import { AdminPropertyForm } from "@/components/admin/admin-property-form"

export default function NewPropertyPage() {
  return <AdminPropertyForm />
}
