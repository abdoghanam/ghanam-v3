import { createClient } from "@/lib/supabase/server"
import { AdminPropertiesList } from "@/components/admin/admin-properties-list"

export default async function AdminPropertiesPage() {
  const supabase = await createClient()

  const { data: properties, error } = await supabase
    .from("properties")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching properties:", error)
  }

  return <AdminPropertiesList properties={properties || []} />
}
