'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function ResetPasswordPage() {
  const [password, setPassword] = useState('')
  const router = useRouter()
  const supabase = createClient()

  const handleReset = async () => {
    const { error } = await supabase.auth.updateUser({ password })
    if (!error) router.push('/admin')
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>تعيين كلمة مرور جديدة</h1>
      <input
        type="password"
        placeholder="كلمة المرور الجديدة"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleReset}>حفظ</button>
    </div>
  )
}
