import type React from "react"
import { createClient } from "@/lib/supabase/server"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"

export const metadata = {
  title: "لوحة التحكم | غنام للعقارات",
  description: "لوحة تحكم إدارة موقع غنام للعقارات",
}

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Allow login page without auth
  if (!user) {
    return children
  }

  return (
    <div className="min-h-screen bg-muted/30" dir="rtl">
      <AdminSidebar user={user} />
      <div className="lg:pr-72">
        <AdminHeader user={user} />
        <main className="p-4 lg:p-6">{children}</main>
      </div>
    </div>
  )
}
