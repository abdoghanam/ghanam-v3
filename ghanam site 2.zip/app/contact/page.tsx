import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import ContactPageContent from "@/components/contact-page-content"

export const metadata = {
  title: "تواصل معنا | غنّام للعقارات",
  description: "تواصل مع غنّام للعقارات - شريكك العقاري الموثوق في المحلة الكبرى. نحن هنا لمساعدتك.",
}

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ContactPageContent />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
