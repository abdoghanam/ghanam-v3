'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function AuthCallbackPage() {
  const router = useRouter()

  useEffect(() => {
    const supabase = createClient()

    supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' || event === 'PASSWORD_RECOVERY') {
        router.replace('/admin/reset-password')
      }
    })
  }, [router])

  return (
    <div style={{ padding: 40, textAlign: 'center' }}>
      جاري التحقق من الحساب...
    </div>
  )
}
