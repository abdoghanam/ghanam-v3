import type React from "react"
import type { Metadata, Viewport } from "next"
import { Cairo, IBM_Plex_Sans_Arabic } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-cairo",
})

const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-ibm",
})

export const metadata: Metadata = {
  metadataBase: new URL("https://ghanam-realestate.com"),
  title: {
    default: "غنّام للعقارات | شريكك العقاري في المحلة الكبرى",
    template: "%s | غنّام للعقارات",
  },
  description:
    "غنّام للعقارات - شريكك العقاري الموثوق في المحلة الكبرى، محافظة الغربية. نقدم خدمات بيع وشراء وإيجار وبدل العقارات بخبرة 15 عاماً. شقق، فيلات، محلات تجارية، وأراضي.",
  keywords: [
    "عقارات المحلة الكبرى",
    "شقق للبيع المحلة",
    "فيلات للبيع الغربية",
    "إيجار شقق المحلة",
    "غنام للعقارات",
    "عقارات الغربية",
    "بيع عقارات مصر",
    "شراء عقارات",
    "محلات تجارية للإيجار",
    "أراضي للبيع",
  ],
  authors: [{ name: "عبدالرحمن غنام", url: "https://ghanam-realestate.com" }],
  creator: "غنّام للعقارات",
  publisher: "غنّام للعقارات",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: "غنّام للعقارات | شريكك العقاري في المحلة الكبرى",
    description: "شريكك العقاري الموثوق في المحلة الكبرى. بيع، شراء، إيجار، وبدل العقارات بخبرة 15 عاماً.",
    url: "https://ghanam-realestate.com",
    siteName: "غنّام للعقارات",
    locale: "ar_EG",
    type: "website",
    images: [
      {
        url: "/images/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "غنّام للعقارات - المحلة الكبرى",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "غنّام للعقارات | المحلة الكبرى",
    description: "شريكك العقاري الموثوق في المحلة الكبرى",
    images: ["/images/og-image.jpg"],
  },
  alternates: {
    canonical: "https://ghanam-realestate.com",
  },
  category: "Real Estate",
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#C6A65D",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
}

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "RealEstateAgent",
  name: "غنّام للعقارات",
  alternateName: "Ghanam Real Estate",
  url: "https://ghanam-realestate.com",
  logo: "https://ghanam-realestate.com/images/ghanam-logo.png",
  description: "شريكك العقاري الموثوق في المحلة الكبرى، محافظة الغربية. خبرة 15 عاماً في سوق العقارات.",
  address: {
    "@type": "PostalAddress",
    addressLocality: "المحلة الكبرى",
    addressRegion: "الغربية",
    addressCountry: "EG",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 30.9754,
    longitude: 31.1622,
  },
  telephone: "+201234567890",
  priceRange: "$$",
  openingHoursSpecification: {
    "@type": "OpeningHoursSpecification",
    dayOfWeek: ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
    opens: "09:00",
    closes: "21:00",
  },
  sameAs: [
    "https://facebook.com/ghanamrealestate",
    "https://instagram.com/ghanamrealestate",
    "https://tiktok.com/@ghanamrealestate",
  ],
  areaServed: {
    "@type": "City",
    name: "المحلة الكبرى",
  },
  knowsAbout: ["Real Estate", "Property Sales", "Property Rentals", "Real Estate Investment"],
  founder: {
    "@type": "Person",
    name: "عبدالرحمن غنام",
    jobTitle: "المدير التنفيذي",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.jpg" />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className={`${cairo.variable} ${ibmPlexArabic.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
