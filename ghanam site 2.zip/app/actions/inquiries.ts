"use server"

import { createClient } from "@/lib/supabase/server"

export async function submitInquiryAction(formData: {
  name: string
  phone: string
  email?: string
  message?: string
  property_id?: number
  property_title?: string
}): Promise<{ success: boolean; error?: string }> {
  const supabase = await createClient()

  const { error } = await supabase.from("inquiries").insert([formData])

  if (error) {
    console.error("Error submitting inquiry:", error)
    return { success: false, error: "حدث خطأ أثناء إرسال الاستفسار. يرجى المحاولة مرة أخرى." }
  }

  return { success: true }
}
