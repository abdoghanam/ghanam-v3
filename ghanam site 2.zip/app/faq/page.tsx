import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import FAQContent from "@/components/faq-content"
import { getFAQs } from "@/lib/supabase/faqs"

export const metadata = {
  title: "الأسئلة الشائعة | غنّام للعقارات",
  description: "إجابات على الأسئلة الشائعة حول خدمات غنّام للعقارات - بيع، شراء، إيجار العقارات في المحلة الكبرى",
}

export default async function FAQPage() {
  const faqs = await getFAQs()

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <FAQContent faqs={faqs} />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
