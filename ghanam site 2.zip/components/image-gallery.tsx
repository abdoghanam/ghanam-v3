"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronRight, ChevronLeft, X, ZoomIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ImageGalleryProps {
  images: string[]
  title: string
}

export default function ImageGallery({ images, title }: ImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length)
  }

  return (
    <>
      {/* Main Gallery */}
      <div className="space-y-4">
        {/* Main Image */}
        <div className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-muted group">
          <Image
            src={images[currentIndex] || "/placeholder.svg?height=600&width=800&query=luxury property interior"}
            alt={`${title} - صورة ${currentIndex + 1}`}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            priority
          />

          {/* Navigation Arrows */}
          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={prevImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-charcoal/50 hover:bg-charcoal/80 text-white rounded-full h-12 w-12 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={nextImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-charcoal/50 hover:bg-charcoal/80 text-white rounded-full h-12 w-12 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
            </>
          )}

          {/* Fullscreen Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFullscreen(true)}
            className="absolute bottom-4 left-4 bg-charcoal/50 hover:bg-charcoal/80 text-white rounded-full h-10 w-10 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ZoomIn className="h-5 w-5" />
          </Button>

          {/* Image Counter */}
          <div className="absolute bottom-4 right-4 bg-charcoal/70 text-white px-3 py-1 rounded-full text-sm">
            {currentIndex + 1} / {images.length}
          </div>
        </div>

        {/* Thumbnails */}
        {images.length > 1 && (
          <div className="flex gap-3 overflow-x-auto pb-2">
            {images.map((image, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={cn(
                  "relative flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden transition-all",
                  currentIndex === index ? "ring-2 ring-gold ring-offset-2" : "opacity-70 hover:opacity-100",
                )}
              >
                <Image
                  src={image || "/placeholder.svg?height=100&width=150&query=property thumbnail"}
                  alt={`${title} - صورة مصغرة ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Fullscreen Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-50 bg-charcoal/95 flex items-center justify-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFullscreen(false)}
            className="absolute top-4 left-4 bg-white/10 hover:bg-white/20 text-white rounded-full h-12 w-12 z-10"
          >
            <X className="h-6 w-6" />
          </Button>

          <div className="relative w-full h-full max-w-6xl max-h-[90vh] mx-4">
            <Image
              src={images[currentIndex] || "/placeholder.svg?height=800&width=1200&query=luxury property"}
              alt={`${title} - صورة ${currentIndex + 1}`}
              fill
              className="object-contain"
            />
          </div>

          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={prevImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white rounded-full h-14 w-14"
              >
                <ChevronRight className="h-8 w-8" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={nextImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white rounded-full h-14 w-14"
              >
                <ChevronLeft className="h-8 w-8" />
              </Button>
            </>
          )}

          {/* Thumbnails in Fullscreen */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={cn(
                  "w-3 h-3 rounded-full transition-all",
                  currentIndex === index ? "bg-gold w-8" : "bg-white/50 hover:bg-white/80",
                )}
              />
            ))}
          </div>
        </div>
      )}
    </>
  )
}
