"use client"

import { useState } from "react"
import { Star, ChevronRight, ChevronLeft, Quote } from "lucide-react"
import { getTestimonials } from "@/lib/properties"
import ScrollReveal from "./scroll-reveal"

export default function TestimonialsSection() {
  const testimonials = getTestimonials()
  const [currentIndex, setCurrentIndex] = useState(0)

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-24 bg-beige-dark/50 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-20 left-10 text-gold/10">
        <Quote className="w-40 h-40" />
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">آراء عملائنا</span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 text-balance">
              كلام الناس أحسن دليل
            </h2>
            <p className="text-gray max-w-2xl mx-auto text-lg leading-relaxed">
              ثقة عملائنا هي أكبر نجاح حققناه، دي بعض آرائهم.
            </p>
          </div>
        </ScrollReveal>

        {/* Testimonials Carousel */}
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <div className="relative">
              <div className="card-3d bg-card rounded-3xl p-8 lg:p-12 border border-border shadow-xl">
                {/* Stars */}
                <div className="flex gap-1 mb-6 justify-center">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-6 h-6 text-gold fill-gold star-animate"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    />
                  ))}
                </div>

                {/* Quote */}
                <blockquote className="text-xl lg:text-2xl text-charcoal text-center leading-relaxed mb-8">
                  "{testimonials[currentIndex].content}"
                </blockquote>

                {/* Author */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-gold">{testimonials[currentIndex].name.charAt(0)}</span>
                  </div>
                  <div className="font-bold text-charcoal text-lg">{testimonials[currentIndex].name}</div>
                  <div className="text-gray text-sm">{testimonials[currentIndex].role}</div>
                </div>
              </div>

              {/* Navigation */}
              <div className="flex justify-center gap-4 mt-8">
                <button
                  onClick={prev}
                  className="w-12 h-12 bg-charcoal hover:bg-charcoal-light text-beige rounded-full flex items-center justify-center transition-colors duration-200"
                  aria-label="السابق"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
                <div className="flex items-center gap-2">
                  {testimonials.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentIndex(i)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        i === currentIndex ? "bg-gold w-8" : "bg-gray/30"
                      }`}
                      aria-label={`الشهادة ${i + 1}`}
                    />
                  ))}
                </div>
                <button
                  onClick={next}
                  className="w-12 h-12 bg-charcoal hover:bg-charcoal-light text-beige rounded-full flex items-center justify-center transition-colors duration-200"
                  aria-label="التالي"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
