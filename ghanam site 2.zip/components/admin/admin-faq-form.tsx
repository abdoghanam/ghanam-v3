"use client"

import type React from "react"

import type { FAQ } from "@/lib/supabase/types"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowRight, Loader2 } from "lucide-react"
import Link from "next/link"

interface AdminFaqFormProps {
  faq?: FAQ
}

const categories = ["عام", "البيع", "الإيجار", "التمويل", "الأوراق والعقود", "خدماتنا"]

export function AdminFaqForm({ faq }: AdminFaqFormProps) {
  const isEditing = !!faq
  const router = useRouter()
  const supabase = createClient()

  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    question: faq?.question || "",
    answer: faq?.answer || "",
    category: faq?.category || "عام",
    order_index: faq?.order_index || 0,
    is_active: faq?.is_active ?? true,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (isEditing) {
        const { error } = await supabase.from("faqs").update(formData).eq("id", faq.id)
        if (error) throw error
      } else {
        const { error } = await supabase.from("faqs").insert([formData])
        if (error) throw error
      }

      router.push("/admin/faqs")
      router.refresh()
    } catch (error) {
      console.error("Error saving FAQ:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/faqs">
            <ArrowRight className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{isEditing ? "تعديل السؤال" : "إضافة سؤال جديد"}</h1>
          <p className="text-muted-foreground">{isEditing ? "تعديل السؤال والإجابة" : "أدخل سؤال جديد وإجابته"}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>بيانات السؤال</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="question">السؤال *</Label>
              <Input
                id="question"
                value={formData.question}
                onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                placeholder="ما هي الأوراق المطلوبة لشراء عقار؟"
                required
              />
            </div>

            <div>
              <Label htmlFor="answer">الإجابة *</Label>
              <Textarea
                id="answer"
                value={formData.answer}
                onChange={(e) => setFormData({ ...formData, answer: e.target.value })}
                placeholder="أدخل الإجابة التفصيلية..."
                rows={5}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">الفئة</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="order">الترتيب</Label>
                <Input
                  id="order"
                  type="number"
                  value={formData.order_index}
                  onChange={(e) => setFormData({ ...formData, order_index: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div>
                <Label>نشط</Label>
                <p className="text-sm text-muted-foreground">يظهر في صفحة الأسئلة الشائعة</p>
              </div>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold-dark text-charcoal h-12">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  جاري الحفظ...
                </>
              ) : isEditing ? (
                "حفظ التعديلات"
              ) : (
                "إضافة السؤال"
              )}
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  )
}
