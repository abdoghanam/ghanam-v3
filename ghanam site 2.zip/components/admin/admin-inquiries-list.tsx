"use client"

import type { Inquiry } from "@/lib/supabase/types"
import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Search, MoreVertical, Eye, Trash2, CheckCircle, Phone, Mail, MessageSquare, Building2 } from "lucide-react"
import Link from "next/link"

interface AdminInquiriesListProps {
  inquiries: Inquiry[]
}

export function AdminInquiriesList({ inquiries: initialInquiries }: AdminInquiriesListProps) {
  const [inquiries, setInquiries] = useState(initialInquiries)
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null)
  const [deleteId, setDeleteId] = useState<number | null>(null)
  const [deleting, setDeleting] = useState(false)
  const supabase = createClient()

  const filteredInquiries = inquiries.filter((i) => {
    const matchesSearch =
      i.name.toLowerCase().includes(search.toLowerCase()) || i.phone.includes(search) || i.email?.includes(search)
    const matchesStatus = statusFilter === "all" || i.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleStatusChange = async (id: number, status: "جديد" | "تم الرد" | "مغلق") => {
    const { error } = await supabase.from("inquiries").update({ status }).eq("id", id)

    if (!error) {
      setInquiries(inquiries.map((i) => (i.id === id ? { ...i, status } : i)))
      if (selectedInquiry?.id === id) {
        setSelectedInquiry({ ...selectedInquiry, status })
      }
    }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleting(true)

    const { error } = await supabase.from("inquiries").delete().eq("id", deleteId)

    if (!error) {
      setInquiries(inquiries.filter((i) => i.id !== deleteId))
    }

    setDeleting(false)
    setDeleteId(null)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "جديد":
        return "bg-gold/10 text-gold border-gold/30"
      case "تم الرد":
        return "bg-green-500/10 text-green-600 border-green-500/20"
      case "مغلق":
        return "bg-muted text-muted-foreground border-border"
      default:
        return ""
    }
  }

  const newCount = inquiries.filter((i) => i.status === "جديد").length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">إدارة الاستفسارات</h1>
        <p className="text-muted-foreground">
          {inquiries.length} استفسار ({newCount} جديد)
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="البحث بالاسم أو الهاتف أو البريد..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                <SelectItem value="جديد">جديد</SelectItem>
                <SelectItem value="تم الرد">تم الرد</SelectItem>
                <SelectItem value="مغلق">مغلق</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Content */}
      {filteredInquiries.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">لا توجد استفسارات</h3>
            <p className="text-muted-foreground">لم يتم العثور على استفسارات تطابق البحث</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الاسم</TableHead>
                  <TableHead>الهاتف</TableHead>
                  <TableHead>العقار</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInquiries.map((inquiry) => (
                  <TableRow key={inquiry.id} className={inquiry.status === "جديد" ? "bg-gold/5" : ""}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{inquiry.name}</p>
                        {inquiry.email && <p className="text-sm text-muted-foreground">{inquiry.email}</p>}
                      </div>
                    </TableCell>
                    <TableCell dir="ltr" className="text-left">
                      <a href={`tel:${inquiry.phone}`} className="text-gold hover:underline">
                        {inquiry.phone}
                      </a>
                    </TableCell>
                    <TableCell>
                      {inquiry.property_id ? (
                        <Link href={`/properties/${inquiry.property_id}`} className="text-gold hover:underline">
                          {inquiry.property_title || `عقار #${inquiry.property_id}`}
                        </Link>
                      ) : (
                        <span className="text-muted-foreground">استفسار عام</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(inquiry.status)}>{inquiry.status}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(inquiry.created_at).toLocaleDateString("ar-EG")}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                          <DropdownMenuItem onClick={() => setSelectedInquiry(inquiry)}>
                            <Eye className="w-4 h-4 ml-2" />
                            عرض التفاصيل
                          </DropdownMenuItem>
                          {inquiry.status !== "تم الرد" && (
                            <DropdownMenuItem onClick={() => handleStatusChange(inquiry.id, "تم الرد")}>
                              <CheckCircle className="w-4 h-4 ml-2" />
                              تحديد كـ"تم الرد"
                            </DropdownMenuItem>
                          )}
                          {inquiry.status !== "مغلق" && (
                            <DropdownMenuItem onClick={() => handleStatusChange(inquiry.id, "مغلق")}>
                              <CheckCircle className="w-4 h-4 ml-2" />
                              إغلاق الاستفسار
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem className="text-destructive" onClick={() => setDeleteId(inquiry.id)}>
                            <Trash2 className="w-4 h-4 ml-2" />
                            حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* View Dialog */}
      <Dialog open={!!selectedInquiry} onOpenChange={() => setSelectedInquiry(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تفاصيل الاستفسار</DialogTitle>
            <DialogDescription>استفسار من {selectedInquiry?.name}</DialogDescription>
          </DialogHeader>
          {selectedInquiry && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="font-medium">{selectedInquiry.name}</p>
                  <Badge className={getStatusColor(selectedInquiry.status)}>{selectedInquiry.status}</Badge>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <a href={`tel:${selectedInquiry.phone}`} className="text-gold hover:underline" dir="ltr">
                    {selectedInquiry.phone}
                  </a>
                </div>
                {selectedInquiry.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <a href={`mailto:${selectedInquiry.email}`} className="text-gold hover:underline">
                      {selectedInquiry.email}
                    </a>
                  </div>
                )}
                {selectedInquiry.property_id && (
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-muted-foreground" />
                    <Link href={`/properties/${selectedInquiry.property_id}`} className="text-gold hover:underline">
                      {selectedInquiry.property_title || `عقار #${selectedInquiry.property_id}`}
                    </Link>
                  </div>
                )}
              </div>

              {selectedInquiry.message && (
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-sm font-medium mb-1">الرسالة:</p>
                  <p className="text-muted-foreground">{selectedInquiry.message}</p>
                </div>
              )}

              <p className="text-sm text-muted-foreground">
                تاريخ الإرسال: {new Date(selectedInquiry.created_at).toLocaleString("ar-EG")}
              </p>
            </div>
          )}
          <DialogFooter className="flex gap-2">
            <Select
              value={selectedInquiry?.status}
              onValueChange={(value: "جديد" | "تم الرد" | "مغلق") =>
                selectedInquiry && handleStatusChange(selectedInquiry.id, value)
              }
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="جديد">جديد</SelectItem>
                <SelectItem value="تم الرد">تم الرد</SelectItem>
                <SelectItem value="مغلق">مغلق</SelectItem>
              </SelectContent>
            </Select>
            <Button
              className="bg-gold hover:bg-gold-dark text-charcoal"
              onClick={() =>
                selectedInquiry && window.open(`https://wa.me/${selectedInquiry.phone.replace(/\D/g, "")}`, "_blank")
              }
            >
              تواصل عبر واتساب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من حذف هذا الاستفسار؟</AlertDialogTitle>
            <AlertDialogDescription>لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "جاري الحذف..." : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
