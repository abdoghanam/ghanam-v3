"use client"

import type { FAQ } from "@/lib/supabase/types"
import { useState } from "react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, MoreVertical, Pencil, Trash2, HelpCircle, GripVertical } from "lucide-react"

interface AdminFaqsListProps {
  faqs: FAQ[]
}

export function AdminFaqsList({ faqs: initialFaqs }: AdminFaqsListProps) {
  const [faqs, setFaqs] = useState(initialFaqs)
  const [deleteId, setDeleteId] = useState<number | null>(null)
  const [deleting, setDeleting] = useState(false)
  const supabase = createClient()

  const handleToggleActive = async (id: number, isActive: boolean) => {
    const { error } = await supabase.from("faqs").update({ is_active: !isActive }).eq("id", id)

    if (!error) {
      setFaqs(faqs.map((f) => (f.id === id ? { ...f, is_active: !isActive } : f)))
    }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleting(true)

    const { error } = await supabase.from("faqs").delete().eq("id", deleteId)

    if (!error) {
      setFaqs(faqs.filter((f) => f.id !== deleteId))
    }

    setDeleting(false)
    setDeleteId(null)
  }

  const categories = [...new Set(faqs.map((f) => f.category))]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">الأسئلة الشائعة</h1>
          <p className="text-muted-foreground">{faqs.length} سؤال</p>
        </div>
        <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
          <Link href="/admin/faqs/new">
            <Plus className="w-4 h-4 ml-2" />
            إضافة سؤال جديد
          </Link>
        </Button>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Badge key={category} variant="outline" className="px-3 py-1">
            {category} ({faqs.filter((f) => f.category === category).length})
          </Badge>
        ))}
      </div>

      {/* Content */}
      {faqs.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <HelpCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">لا توجد أسئلة</h3>
            <p className="text-muted-foreground mb-4">أضف أسئلة شائعة لمساعدة العملاء</p>
            <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
              <Link href="/admin/faqs/new">
                <Plus className="w-4 h-4 ml-2" />
                إضافة سؤال
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10"></TableHead>
                  <TableHead>السؤال</TableHead>
                  <TableHead>الفئة</TableHead>
                  <TableHead>الترتيب</TableHead>
                  <TableHead>نشط</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {faqs.map((faq) => (
                  <TableRow key={faq.id} className={!faq.is_active ? "opacity-50" : ""}>
                    <TableCell>
                      <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium line-clamp-1">{faq.question}</p>
                        <p className="text-sm text-muted-foreground line-clamp-1">{faq.answer}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{faq.category}</Badge>
                    </TableCell>
                    <TableCell>{faq.order_index}</TableCell>
                    <TableCell>
                      <Switch
                        checked={faq.is_active}
                        onCheckedChange={() => handleToggleActive(faq.id, faq.is_active)}
                      />
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                          <DropdownMenuItem asChild>
                            <Link href={`/admin/faqs/${faq.id}`}>
                              <Pencil className="w-4 h-4 ml-2" />
                              تعديل
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => setDeleteId(faq.id)}>
                            <Trash2 className="w-4 h-4 ml-2" />
                            حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من حذف هذا السؤال؟</AlertDialogTitle>
            <AlertDialogDescription>لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "جاري الحذف..." : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
