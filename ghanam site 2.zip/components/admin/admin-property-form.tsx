"use client"

import type React from "react"

import type { Property } from "@/lib/supabase/types"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowRight, Loader2, Plus, X, Upload, Building2 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface AdminPropertyFormProps {
  property?: Property
}

export function AdminPropertyForm({ property }: AdminPropertyFormProps) {
  const isEditing = !!property
  const router = useRouter()
  const supabase = createClient()

  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: property?.title || "",
    location: property?.location || "",
    price: property?.price || 0,
    price_type: property?.price_type || "جنيه",
    type: property?.type || "بيع",
    category: property?.category || "شقة",
    area: property?.area || 0,
    bedrooms: property?.bedrooms || 0,
    bathrooms: property?.bathrooms || 0,
    floor: property?.floor || 0,
    total_floors: property?.total_floors || 0,
    year_built: property?.year_built || new Date().getFullYear(),
    status: property?.status || "متاح",
    featured: property?.featured || false,
    description: property?.description || "",
    images: property?.images || [],
    features: property?.features || [],
    coordinates: property?.coordinates || { lat: 30.0444, lng: 31.2357 },
  })

  const [newFeature, setNewFeature] = useState("")
  const [newImageUrl, setNewImageUrl] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (isEditing) {
        const { error } = await supabase
          .from("properties")
          .update({ ...formData, updated_at: new Date().toISOString() })
          .eq("id", property.id)

        if (error) throw error
      } else {
        const { error } = await supabase.from("properties").insert([formData])
        if (error) throw error
      }

      router.push("/admin/properties")
      router.refresh()
    } catch (error) {
      console.error("Error saving property:", error)
    } finally {
      setLoading(false)
    }
  }

  const addFeature = () => {
    if (newFeature.trim()) {
      setFormData({ ...formData, features: [...formData.features, newFeature.trim()] })
      setNewFeature("")
    }
  }

  const removeFeature = (index: number) => {
    setFormData({ ...formData, features: formData.features.filter((_, i) => i !== index) })
  }

  const addImage = () => {
    if (newImageUrl.trim()) {
      setFormData({ ...formData, images: [...formData.images, newImageUrl.trim()] })
      setNewImageUrl("")
    }
  }

  const removeImage = (index: number) => {
    setFormData({ ...formData, images: formData.images.filter((_, i) => i !== index) })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/properties">
            <ArrowRight className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{isEditing ? "تعديل العقار" : "إضافة عقار جديد"}</h1>
          <p className="text-muted-foreground">{isEditing ? "تعديل بيانات العقار" : "أدخل بيانات العقار الجديد"}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>المعلومات الأساسية</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <Label htmlFor="title">عنوان العقار *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="شقة فاخرة للبيع في مدينة نصر"
                      required
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="location">الموقع *</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="مدينة نصر، القاهرة"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="type">نوع العرض *</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: "بيع" | "إيجار" | "بدل") => setFormData({ ...formData, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="بيع">بيع</SelectItem>
                        <SelectItem value="إيجار">إيجار</SelectItem>
                        <SelectItem value="بدل">بدل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="category">فئة العقار *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value: "شقة" | "فيلا" | "تجاري" | "أرض" | "مكتب") =>
                        setFormData({ ...formData, category: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="شقة">شقة</SelectItem>
                        <SelectItem value="فيلا">فيلا</SelectItem>
                        <SelectItem value="تجاري">تجاري</SelectItem>
                        <SelectItem value="أرض">أرض</SelectItem>
                        <SelectItem value="مكتب">مكتب</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="price">السعر *</Label>
                    <Input
                      id="price"
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="price_type">العملة</Label>
                    <Select
                      value={formData.price_type}
                      onValueChange={(value) => setFormData({ ...formData, price_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="جنيه">جنيه مصري</SelectItem>
                        <SelectItem value="دولار">دولار أمريكي</SelectItem>
                        <SelectItem value="يورو">يورو</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="status">الحالة</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: "متاح" | "محجوز" | "مباع") => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="متاح">متاح</SelectItem>
                        <SelectItem value="محجوز">محجوز</SelectItem>
                        <SelectItem value="مباع">مباع</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>تفاصيل العقار</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="area">المساحة (م²) *</Label>
                    <Input
                      id="area"
                      type="number"
                      value={formData.area}
                      onChange={(e) => setFormData({ ...formData, area: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="bedrooms">غرف النوم</Label>
                    <Input
                      id="bedrooms"
                      type="number"
                      value={formData.bedrooms}
                      onChange={(e) => setFormData({ ...formData, bedrooms: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="bathrooms">الحمامات</Label>
                    <Input
                      id="bathrooms"
                      type="number"
                      value={formData.bathrooms}
                      onChange={(e) => setFormData({ ...formData, bathrooms: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="floor">الطابق</Label>
                    <Input
                      id="floor"
                      type="number"
                      value={formData.floor}
                      onChange={(e) => setFormData({ ...formData, floor: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="total_floors">إجمالي الطوابق</Label>
                    <Input
                      id="total_floors"
                      type="number"
                      value={formData.total_floors}
                      onChange={(e) => setFormData({ ...formData, total_floors: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="year_built">سنة البناء</Label>
                    <Input
                      id="year_built"
                      type="number"
                      value={formData.year_built}
                      onChange={(e) => setFormData({ ...formData, year_built: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">وصف العقار</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="أدخل وصف تفصيلي للعقار..."
                    rows={5}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>مميزات العقار</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newFeature}
                    onChange={(e) => setNewFeature(e.target.value)}
                    placeholder="مثال: تكييف مركزي"
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addFeature())}
                  />
                  <Button type="button" onClick={addFeature} className="bg-gold hover:bg-gold-dark text-charcoal">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 px-3 py-1 bg-muted rounded-full text-sm">
                      {feature}
                      <button type="button" onClick={() => removeFeature(index)}>
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>الصور</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="رابط الصورة"
                    dir="ltr"
                  />
                  <Button type="button" onClick={addImage} className="bg-gold hover:bg-gold-dark text-charcoal">
                    <Upload className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative aspect-video rounded-lg overflow-hidden bg-muted group">
                      <Image src={image || "/placeholder.svg"} alt="" fill className="object-cover" />
                      <button
                        type="button"
                        onClick={() => removeImage(index)}
                        className="absolute top-1 right-1 p-1 bg-destructive text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
                {formData.images.length === 0 && (
                  <div className="aspect-video rounded-lg bg-muted flex items-center justify-center">
                    <Building2 className="w-12 h-12 text-muted-foreground" />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>إحداثيات الموقع</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="lat">خط العرض (Latitude)</Label>
                  <Input
                    id="lat"
                    type="number"
                    step="any"
                    value={formData.coordinates.lat}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        coordinates: { ...formData.coordinates, lat: Number(e.target.value) },
                      })
                    }
                    dir="ltr"
                  />
                </div>
                <div>
                  <Label htmlFor="lng">خط الطول (Longitude)</Label>
                  <Input
                    id="lng"
                    type="number"
                    step="any"
                    value={formData.coordinates.lng}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        coordinates: { ...formData.coordinates, lng: Number(e.target.value) },
                      })
                    }
                    dir="ltr"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>خيارات النشر</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>عقار مميز</Label>
                    <p className="text-sm text-muted-foreground">يظهر في الصفحة الرئيسية</p>
                  </div>
                  <Switch
                    checked={formData.featured}
                    onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold-dark text-charcoal h-12">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  جاري الحفظ...
                </>
              ) : isEditing ? (
                "حفظ التعديلات"
              ) : (
                "إضافة العقار"
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
