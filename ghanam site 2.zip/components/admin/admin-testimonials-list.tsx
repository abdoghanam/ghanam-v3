"use client"

import type { Testimonial } from "@/lib/supabase/types"
import { useState } from "react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, MoreVertical, Pencil, Trash2, Star, Quote } from "lucide-react"

interface AdminTestimonialsListProps {
  testimonials: Testimonial[]
}

export function AdminTestimonialsList({ testimonials: initialTestimonials }: AdminTestimonialsListProps) {
  const [testimonials, setTestimonials] = useState(initialTestimonials)
  const [deleteId, setDeleteId] = useState<number | null>(null)
  const [deleting, setDeleting] = useState(false)
  const supabase = createClient()

  const handleToggleActive = async (id: number, isActive: boolean) => {
    const { error } = await supabase.from("testimonials").update({ is_active: !isActive }).eq("id", id)

    if (!error) {
      setTestimonials(testimonials.map((t) => (t.id === id ? { ...t, is_active: !isActive } : t)))
    }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleting(true)

    const { error } = await supabase.from("testimonials").delete().eq("id", deleteId)

    if (!error) {
      setTestimonials(testimonials.filter((t) => t.id !== deleteId))
    }

    setDeleting(false)
    setDeleteId(null)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">آراء العملاء</h1>
          <p className="text-muted-foreground">{testimonials.length} رأي</p>
        </div>
        <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
          <Link href="/admin/testimonials/new">
            <Plus className="w-4 h-4 ml-2" />
            إضافة رأي جديد
          </Link>
        </Button>
      </div>

      {/* Content */}
      {testimonials.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Quote className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">لا توجد آراء</h3>
            <p className="text-muted-foreground mb-4">أضف آراء العملاء لعرضها في الموقع</p>
            <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
              <Link href="/admin/testimonials/new">
                <Plus className="w-4 h-4 ml-2" />
                إضافة رأي
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className={!testimonial.is_active ? "opacity-50" : ""}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center">
                      <span className="text-gold font-semibold">{testimonial.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-medium">{testimonial.name}</p>
                      {testimonial.role && <p className="text-sm text-muted-foreground">{testimonial.role}</p>}
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start">
                      <DropdownMenuItem asChild>
                        <Link href={`/admin/testimonials/${testimonial.id}`}>
                          <Pencil className="w-4 h-4 ml-2" />
                          تعديل
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => setDeleteId(testimonial.id)}>
                        <Trash2 className="w-4 h-4 ml-2" />
                        حذف
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex gap-0.5 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < testimonial.rating ? "fill-gold text-gold" : "text-muted"}`}
                    />
                  ))}
                </div>

                <p className="text-muted-foreground text-sm line-clamp-3 mb-3">{testimonial.content}</p>

                <div className="flex items-center justify-between pt-3 border-t">
                  <span className="text-sm text-muted-foreground">الترتيب: {testimonial.order_index}</span>
                  <Switch
                    checked={testimonial.is_active}
                    onCheckedChange={() => handleToggleActive(testimonial.id, testimonial.is_active)}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من حذف هذا الرأي؟</AlertDialogTitle>
            <AlertDialogDescription>لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "جاري الحذف..." : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
