"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Save, Building2, Phone, Mail, MapPin, Globe, MessageCircle } from "lucide-react"

interface AdminSettingsFormProps {
  settings: Record<string, string>
}

export function AdminSettingsForm({ settings: initialSettings }: AdminSettingsFormProps) {
  const [settings, setSettings] = useState(initialSettings)
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const updateSetting = (key: string, value: string) => {
    setSettings({ ...settings, [key]: value })
    setSaved(false)
  }

  const handleSave = async () => {
    setLoading(true)
    setSaved(false)

    try {
      // Update each setting
      for (const [key, value] of Object.entries(settings)) {
        await supabase
          .from("site_settings")
          .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: "key" })
      }

      setSaved(true)
      router.refresh()
    } catch (error) {
      console.error("Error saving settings:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">الإعدادات</h1>
          <p className="text-muted-foreground">إدارة إعدادات الموقع</p>
        </div>
        <Button onClick={handleSave} disabled={loading} className="bg-gold hover:bg-gold-dark text-charcoal">
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
              جاري الحفظ...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 ml-2" />
              حفظ التغييرات
            </>
          )}
        </Button>
      </div>

      {saved && (
        <div className="bg-green-500/10 text-green-600 border border-green-500/20 rounded-lg p-4">
          تم حفظ الإعدادات بنجاح
        </div>
      )}

      <Tabs defaultValue="general" dir="rtl">
        <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="contact">التواصل</TabsTrigger>
          <TabsTrigger value="social">التواصل الاجتماعي</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-gold" />
                معلومات الموقع
              </CardTitle>
              <CardDescription>المعلومات الأساسية للموقع</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="site_name">اسم الموقع</Label>
                  <Input
                    id="site_name"
                    value={settings.site_name || ""}
                    onChange={(e) => updateSetting("site_name", e.target.value)}
                    placeholder="غنّام للعقارات"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="site_tagline">الشعار النصي</Label>
                  <Input
                    id="site_tagline"
                    value={settings.site_tagline || ""}
                    onChange={(e) => updateSetting("site_tagline", e.target.value)}
                    placeholder="السوق له قواعد... وإحنا فاهمينها"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contact Settings */}
        <TabsContent value="contact" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-gold" />
                معلومات التواصل
              </CardTitle>
              <CardDescription>أرقام الهاتف والعناوين</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="site_phone" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    رقم الهاتف
                  </Label>
                  <Input
                    id="site_phone"
                    value={settings.site_phone || ""}
                    onChange={(e) => updateSetting("site_phone", e.target.value)}
                    placeholder="201011244308"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="site_email" className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    البريد الإلكتروني
                  </Label>
                  <Input
                    id="site_email"
                    type="email"
                    value={settings.site_email || ""}
                    onChange={(e) => updateSetting("site_email", e.target.value)}
                    placeholder="info@ghanam.com"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="site_address" className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    العنوان
                  </Label>
                  <Input
                    id="site_address"
                    value={settings.site_address || ""}
                    onChange={(e) => updateSetting("site_address", e.target.value)}
                    placeholder="المحلة الكبرى، مصر"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Social Settings */}
        <TabsContent value="social" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-gold" />
                روابط التواصل الاجتماعي
              </CardTitle>
              <CardDescription>روابط صفحات التواصل الاجتماعي</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="whatsapp_number" className="flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    رقم واتساب
                  </Label>
                  <Input
                    id="whatsapp_number"
                    value={settings.whatsapp_number || ""}
                    onChange={(e) => updateSetting("whatsapp_number", e.target.value)}
                    placeholder="201011244308"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="facebook_url">رابط فيسبوك</Label>
                  <Input
                    id="facebook_url"
                    value={settings.facebook_url || ""}
                    onChange={(e) => updateSetting("facebook_url", e.target.value)}
                    placeholder="https://facebook.com/ghanam"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instagram_url">رابط انستجرام</Label>
                  <Input
                    id="instagram_url"
                    value={settings.instagram_url || ""}
                    onChange={(e) => updateSetting("instagram_url", e.target.value)}
                    placeholder="https://instagram.com/ghanam"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="youtube_url">رابط يوتيوب</Label>
                  <Input
                    id="youtube_url"
                    value={settings.youtube_url || ""}
                    onChange={(e) => updateSetting("youtube_url", e.target.value)}
                    placeholder="https://youtube.com/@ghanam"
                    dir="ltr"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
