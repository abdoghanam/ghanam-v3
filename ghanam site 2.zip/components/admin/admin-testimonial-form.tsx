"use client"

import type React from "react"

import type { Testimonial } from "@/lib/supabase/types"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { ArrowRight, Loader2, Star } from "lucide-react"
import Link from "next/link"

interface AdminTestimonialFormProps {
  testimonial?: Testimonial
}

export function AdminTestimonialForm({ testimonial }: AdminTestimonialFormProps) {
  const isEditing = !!testimonial
  const router = useRouter()
  const supabase = createClient()

  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: testimonial?.name || "",
    role: testimonial?.role || "",
    content: testimonial?.content || "",
    rating: testimonial?.rating || 5,
    avatar_url: testimonial?.avatar_url || "",
    order_index: testimonial?.order_index || 0,
    is_active: testimonial?.is_active ?? true,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (isEditing) {
        const { error } = await supabase.from("testimonials").update(formData).eq("id", testimonial.id)
        if (error) throw error
      } else {
        const { error } = await supabase.from("testimonials").insert([formData])
        if (error) throw error
      }

      router.push("/admin/testimonials")
      router.refresh()
    } catch (error) {
      console.error("Error saving testimonial:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/testimonials">
            <ArrowRight className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{isEditing ? "تعديل الرأي" : "إضافة رأي جديد"}</h1>
          <p className="text-muted-foreground">{isEditing ? "تعديل رأي العميل" : "أدخل رأي العميل الجديد"}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>بيانات الرأي</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">اسم العميل *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="أحمد محمد"
                  required
                />
              </div>
              <div>
                <Label htmlFor="role">الصفة</Label>
                <Input
                  id="role"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  placeholder="مستثمر عقاري"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="content">الرأي *</Label>
              <Textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="تجربة ممتازة مع غنام للعقارات..."
                rows={4}
                required
              />
            </div>

            <div>
              <Label>التقييم</Label>
              <div className="flex gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setFormData({ ...formData, rating: star })}
                    className="p-1"
                  >
                    <Star
                      className={`w-6 h-6 transition-colors ${
                        star <= formData.rating ? "fill-gold text-gold" : "text-muted hover:text-gold/50"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="avatar">رابط الصورة</Label>
                <Input
                  id="avatar"
                  value={formData.avatar_url}
                  onChange={(e) => setFormData({ ...formData, avatar_url: e.target.value })}
                  placeholder="https://..."
                  dir="ltr"
                />
              </div>
              <div>
                <Label htmlFor="order">الترتيب</Label>
                <Input
                  id="order"
                  type="number"
                  value={formData.order_index}
                  onChange={(e) => setFormData({ ...formData, order_index: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div>
                <Label>نشط</Label>
                <p className="text-sm text-muted-foreground">يظهر في الموقع</p>
              </div>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full bg-gold hover:bg-gold-dark text-charcoal h-12">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  جاري الحفظ...
                </>
              ) : isEditing ? (
                "حفظ التعديلات"
              ) : (
                "إضافة الرأي"
              )}
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  )
}
