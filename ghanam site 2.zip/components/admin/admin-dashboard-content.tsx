"use client"

import type { DashboardStats, Inquiry } from "@/lib/supabase/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Building2, MessageSquare, TrendingUp, Eye, Plus, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface AdminDashboardContentProps {
  stats: DashboardStats
}

export function AdminDashboardContent({ stats }: AdminDashboardContentProps) {
  const statCards = [
    {
      title: "إجمالي العقارات",
      value: stats.totalProperties,
      icon: Building2,
      color: "bg-blue-500",
      href: "/admin/properties",
    },
    {
      title: "عقارات متاحة",
      value: stats.availableProperties,
      icon: TrendingUp,
      color: "bg-green-500",
      href: "/admin/properties?status=متاح",
    },
    {
      title: "استفسارات جديدة",
      value: stats.newInquiries,
      icon: MessageSquare,
      color: "bg-gold",
      href: "/admin/inquiries?status=جديد",
    },
    {
      title: "إجمالي الاستفسارات",
      value: stats.totalInquiries,
      icon: Eye,
      color: "bg-purple-500",
      href: "/admin/inquiries",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-muted-foreground">مرحباً بك في لوحة التحكم</p>
        </div>
        <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
          <Link href="/admin/properties/new">
            <Plus className="w-4 h-4 ml-2" />
            إضافة عقار جديد
          </Link>
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                    <p className="text-3xl font-bold text-foreground">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-xl ${stat.color} flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Inquiries */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">آخر الاستفسارات</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/inquiries">
                عرض الكل
                <ArrowLeft className="w-4 h-4 mr-1" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            {stats.recentInquiries.length > 0 ? (
              <div className="space-y-4">
                {stats.recentInquiries.map((inquiry: Inquiry) => (
                  <div key={inquiry.id} className="flex items-start gap-4 p-3 rounded-lg bg-muted/50">
                    <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center shrink-0">
                      <MessageSquare className="w-5 h-5 text-gold" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-foreground truncate">{inquiry.name}</p>
                        <Badge
                          variant={inquiry.status === "جديد" ? "default" : "secondary"}
                          className={inquiry.status === "جديد" ? "bg-gold/20 text-gold border-gold/30" : ""}
                        >
                          {inquiry.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {inquiry.property_title || "استفسار عام"}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(inquiry.created_at).toLocaleDateString("ar-EG")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">لا توجد استفسارات حالياً</div>
            )}
          </CardContent>
        </Card>

        {/* Properties by Type */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">العقارات حسب النوع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.propertiesByType.map((item) => (
                <div key={item.type} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{item.type}</span>
                  <div className="flex items-center gap-3">
                    <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gold rounded-full"
                        style={{
                          width: `${stats.totalProperties > 0 ? (item.count / stats.totalProperties) * 100 : 0}%`,
                        }}
                      />
                    </div>
                    <span className="font-semibold text-foreground w-8 text-left">{item.count}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-border">
              <h4 className="font-medium text-foreground mb-4">حسب الفئة</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {stats.propertiesByCategory.map((item) => (
                  <div key={item.category} className="text-center p-3 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-foreground">{item.count}</p>
                    <p className="text-sm text-muted-foreground">{item.category}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">إجراءات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto py-4 flex-col bg-transparent" asChild>
              <Link href="/admin/properties/new">
                <Building2 className="w-6 h-6 mb-2 text-gold" />
                <span>إضافة عقار</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col bg-transparent" asChild>
              <Link href="/admin/inquiries">
                <MessageSquare className="w-6 h-6 mb-2 text-gold" />
                <span>الاستفسارات</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col bg-transparent" asChild>
              <Link href="/admin/faqs/new">
                <Plus className="w-6 h-6 mb-2 text-gold" />
                <span>إضافة سؤال</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col bg-transparent" asChild>
              <Link href="/admin/settings">
                <TrendingUp className="w-6 h-6 mb-2 text-gold" />
                <span>الإعدادات</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
