"use client"

import { useState, useEffect, useCallback, useTransition } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import {
  MapPin,
  Maximize2,
  BedDouble,
  Bath,
  Filter,
  Search,
  SlidersHorizontal,
  X,
  Grid3X3,
  List,
  CheckCircle,
  Loader2,
} from "lucide-react"
import type { Property } from "@/lib/supabase/types"
import ScrollReveal from "./scroll-reveal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

const filterTypes = ["الكل", "بيع", "إيجار"]
const categories = ["الكل", "شقة", "فيلا", "تجاري", "أرض"]
const bedroomOptions = ["الكل", "1", "2", "3", "4", "5+"]
const sortOptions = [
  { value: "newest", label: "الأحدث" },
  { value: "price-asc", label: "السعر: من الأقل للأعلى" },
  { value: "price-desc", label: "السعر: من الأعلى للأقل" },
  { value: "area-desc", label: "المساحة: من الأكبر للأصغر" },
]

type ViewMode = "grid" | "list"

interface PropertiesPageContentProps {
  initialProperties: Property[]
}

export default function PropertiesPageContent({ initialProperties }: PropertiesPageContentProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isPending, startTransition] = useTransition()

  const [properties, setProperties] = useState<Property[]>(initialProperties)
  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "")
  const [activeType, setActiveType] = useState(searchParams.get("type") || "الكل")
  const [activeCategory, setActiveCategory] = useState(searchParams.get("category") || "الكل")
  const [activeBedrooms, setActiveBedrooms] = useState(searchParams.get("bedrooms") || "الكل")
  const [priceRange, setPriceRange] = useState([
    Number(searchParams.get("minPrice")) || 0,
    Number(searchParams.get("maxPrice")) || 5000000,
  ])
  const [areaRange, setAreaRange] = useState([
    Number(searchParams.get("minArea")) || 0,
    Number(searchParams.get("maxArea")) || 1000,
  ])
  const [sortBy, setSortBy] = useState(searchParams.get("sortBy") || "newest")
  const [viewMode, setViewMode] = useState<ViewMode>("grid")
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const updateFilters = useCallback(() => {
    const params = new URLSearchParams()

    if (searchQuery) params.set("search", searchQuery)
    if (activeType !== "الكل") params.set("type", activeType)
    if (activeCategory !== "الكل") params.set("category", activeCategory)
    if (activeBedrooms !== "الكل") params.set("bedrooms", activeBedrooms)
    if (priceRange[0] > 0) params.set("minPrice", priceRange[0].toString())
    if (priceRange[1] < 5000000) params.set("maxPrice", priceRange[1].toString())
    if (areaRange[0] > 0) params.set("minArea", areaRange[0].toString())
    if (areaRange[1] < 1000) params.set("maxArea", areaRange[1].toString())
    if (sortBy !== "newest") params.set("sortBy", sortBy)

    startTransition(() => {
      router.push(`/properties?${params.toString()}`, { scroll: false })
    })
  }, [searchQuery, activeType, activeCategory, activeBedrooms, priceRange, areaRange, sortBy, router])

  // Debounce filter updates
  useEffect(() => {
    const timer = setTimeout(() => {
      updateFilters()
    }, 300)
    return () => clearTimeout(timer)
  }, [updateFilters])

  // Update properties when initialProperties change (from server)
  useEffect(() => {
    setProperties(initialProperties)
  }, [initialProperties])

  const activeFiltersCount = [
    activeType !== "الكل",
    activeCategory !== "الكل",
    activeBedrooms !== "الكل",
    priceRange[0] > 0 || priceRange[1] < 5000000,
    areaRange[0] > 0 || areaRange[1] < 1000,
  ].filter(Boolean).length

  const resetFilters = () => {
    setSearchQuery("")
    setActiveType("الكل")
    setActiveCategory("الكل")
    setActiveBedrooms("الكل")
    setPriceRange([0, 5000000])
    setAreaRange([0, 1000])
    setSortBy("newest")
    router.push("/properties")
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("ar-EG")
  }

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Type Filter */}
      <div>
        <Label className="text-charcoal font-semibold mb-3 block">نوع العرض</Label>
        <div className="flex flex-wrap gap-2">
          {filterTypes.map((type) => (
            <button
              key={type}
              onClick={() => setActiveType(type)}
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                activeType === type ? "bg-gold text-charcoal" : "bg-beige-dark text-gray hover:bg-beige",
              )}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Category Filter */}
      <div>
        <Label className="text-charcoal font-semibold mb-3 block">نوع العقار</Label>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                activeCategory === category ? "bg-gold text-charcoal" : "bg-beige-dark text-gray hover:bg-beige",
              )}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Bedrooms Filter */}
      <div>
        <Label className="text-charcoal font-semibold mb-3 block">غرف النوم</Label>
        <div className="flex flex-wrap gap-2">
          {bedroomOptions.map((option) => (
            <button
              key={option}
              onClick={() => setActiveBedrooms(option)}
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200 min-w-[48px]",
                activeBedrooms === option ? "bg-gold text-charcoal" : "bg-beige-dark text-gray hover:bg-beige",
              )}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <Label className="text-charcoal font-semibold mb-3 block">
          نطاق السعر: {formatPrice(priceRange[0])} - {formatPrice(priceRange[1])} جنيه
        </Label>
        <Slider value={priceRange} onValueChange={setPriceRange} max={5000000} step={50000} className="mt-4" />
      </div>

      {/* Area Range */}
      <div>
        <Label className="text-charcoal font-semibold mb-3 block">
          المساحة: {areaRange[0]} - {areaRange[1]} م²
        </Label>
        <Slider value={areaRange} onValueChange={setAreaRange} max={1000} step={10} className="mt-4" />
      </div>

      {/* Reset Button */}
      {activeFiltersCount > 0 && (
        <Button variant="outline" onClick={resetFilters} className="w-full gap-2 bg-transparent">
          <X className="h-4 w-4" />
          إعادة تعيين الفلاتر ({activeFiltersCount})
        </Button>
      )}
    </div>
  )

  return (
    <section className="pt-32 pb-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Page Header */}
        <ScrollReveal>
          <div className="text-center mb-12">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">استكشف الفرص</span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 text-balance">
              جميع العقارات المتاحة
            </h1>
            <p className="text-gray max-w-2xl mx-auto text-lg leading-relaxed">
              تصفح مجموعتنا الكاملة من العقارات في المحلة الكبرى
            </p>
          </div>
        </ScrollReveal>

        {/* Search & Controls Bar */}
        <ScrollReveal delay={100}>
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center mb-6 bg-card p-4 rounded-2xl border border-border">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray" />
              <Input
                type="text"
                placeholder="ابحث بالعنوان، الموقع، أو الوصف..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-12 h-12"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")} className="absolute left-4 top-1/2 -translate-y-1/2">
                  <X className="w-4 h-4 text-gray hover:text-charcoal" />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Quick Type Filter - Desktop */}
              <div className="hidden md:flex items-center gap-2">
                {filterTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => setActiveType(type)}
                    className={cn(
                      "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                      activeType === type ? "bg-gold text-charcoal" : "bg-background text-gray hover:bg-beige-dark",
                    )}
                  >
                    {type}
                  </button>
                ))}
              </div>

              {/* Sort Dropdown */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px] h-12">
                  <SelectValue placeholder="ترتيب حسب" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* View Mode Toggle */}
              <div className="hidden sm:flex items-center gap-1 bg-beige-dark rounded-lg p-1">
                <button
                  onClick={() => setViewMode("grid")}
                  className={cn(
                    "p-2 rounded-md transition-colors",
                    viewMode === "grid" ? "bg-card text-charcoal shadow-sm" : "text-gray",
                  )}
                >
                  <Grid3X3 className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={cn(
                    "p-2 rounded-md transition-colors",
                    viewMode === "list" ? "bg-card text-charcoal shadow-sm" : "text-gray",
                  )}
                >
                  <List className="h-5 w-5" />
                </button>
              </div>

              {/* Advanced Filter Button - Mobile */}
              <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden gap-2 h-12 bg-transparent relative">
                    <SlidersHorizontal className="h-5 w-5" />
                    فلاتر
                    {activeFiltersCount > 0 && (
                      <Badge className="absolute -top-2 -left-2 bg-gold text-charcoal h-5 w-5 p-0 flex items-center justify-center text-xs">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[320px]">
                  <SheetHeader>
                    <SheetTitle>فلترة العقارات</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterContent />
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </ScrollReveal>

        <div className="flex gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <div className="sticky top-24 bg-card p-6 rounded-2xl border border-border">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-charcoal flex items-center gap-2">
                  <Filter className="h-5 w-5 text-gold" />
                  فلترة متقدمة
                </h3>
                {activeFiltersCount > 0 && <Badge className="bg-gold/10 text-gold">{activeFiltersCount} فلتر</Badge>}
              </div>
              <FilterContent />
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            {/* Results count & Active Filters */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <p className="text-gray flex items-center gap-2">
                {isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                عرض <span className="font-bold text-charcoal">{properties.length}</span> عقار
              </p>

              {/* Active Filter Tags */}
              {activeFiltersCount > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  {activeType !== "الكل" && (
                    <Badge variant="secondary" className="gap-1">
                      {activeType}
                      <button onClick={() => setActiveType("الكل")}>
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  )}
                  {activeCategory !== "الكل" && (
                    <Badge variant="secondary" className="gap-1">
                      {activeCategory}
                      <button onClick={() => setActiveCategory("الكل")}>
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  )}
                  {activeBedrooms !== "الكل" && (
                    <Badge variant="secondary" className="gap-1">
                      {activeBedrooms} غرف
                      <button onClick={() => setActiveBedrooms("الكل")}>
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  )}
                </div>
              )}
            </div>

            {/* Properties Grid/List */}
            <div
              className={cn(viewMode === "grid" ? "grid md:grid-cols-2 xl:grid-cols-3 gap-6" : "flex flex-col gap-4")}
            >
              {properties.map((property, index) => (
                <ScrollReveal key={property.id} delay={index * 50}>
                  {viewMode === "grid" ? (
                    <PropertyGridCard property={property} />
                  ) : (
                    <PropertyListCard property={property} />
                  )}
                </ScrollReveal>
              ))}
            </div>

            {/* Empty State */}
            {properties.length === 0 && !isPending && (
              <div className="text-center py-16 bg-card rounded-2xl border border-border">
                <Search className="h-16 w-16 text-gray/30 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-charcoal mb-2">لا توجد عقارات مطابقة</h3>
                <p className="text-gray mb-6">جرب تغيير معايير البحث أو الفلاتر</p>
                <Button onClick={resetFilters} className="bg-gold hover:bg-gold-dark text-charcoal">
                  إعادة تعيين الفلاتر
                </Button>
              </div>
            )}

            {/* Loading State */}
            {isPending && properties.length === 0 && (
              <div className="text-center py-16">
                <Loader2 className="h-12 w-12 animate-spin text-gold mx-auto mb-4" />
                <p className="text-gray">جاري البحث...</p>
              </div>
            )}
          </div>
        </div>

        {/* CTA */}
        <ScrollReveal>
          <div className="text-center mt-16 bg-charcoal rounded-3xl p-8 lg:p-12">
            <h3 className="text-2xl lg:text-3xl font-bold text-beige mb-4">مش لاقي اللي بتدور عليه؟</h3>
            <p className="text-beige/70 mb-6 max-w-xl mx-auto">
              تواصل معانا وقولنا احتياجاتك، وهنوصلك بالعقار المناسب في أقرب وقت
            </p>
            <Link
              href="https://wa.me/201011244308?text=أبحث عن عقار بمواصفات معينة"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-gold hover:bg-gold-light text-charcoal px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 glow-gold"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              تواصل عبر واتساب
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}

function PropertyGridCard({ property }: { property: Property }) {
  const isNew = new Date(property.created_at) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

  return (
    <Link href={`/properties/${property.id}`} className="block h-full">
      <div className="card-3d group bg-card rounded-2xl overflow-hidden border border-border hover:border-gold/50 transition-all duration-300 h-full">
        {/* Image Container */}
        <div className="relative h-56 overflow-hidden">
          <Image
            src={property.images?.[0] || "/placeholder.svg?height=300&width=400&query=modern property"}
            alt={property.title}
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
          />
          {/* Badges */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <span
              className={cn(
                "px-3 py-1 rounded-full text-xs font-semibold",
                property.type === "بيع" ? "bg-green text-beige" : "bg-gold text-charcoal",
              )}
            >
              {property.type}
            </span>
            {property.status === "متاح" && (
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green/90 text-white flex items-center gap-1">
                <CheckCircle className="h-3 w-3" />
                متاح
              </span>
            )}
          </div>
          {isNew && (
            <div className="absolute top-4 left-4">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-charcoal text-beige">جديد</span>
            </div>
          )}
          {property.featured && !isNew && (
            <div className="absolute top-4 left-4">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-charcoal text-beige">مميز</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-5">
          <h3 className="font-bold text-charcoal mb-2 line-clamp-1">{property.title}</h3>

          <div className="flex items-center gap-1 text-gray text-sm mb-4">
            <MapPin className="w-4 h-4 text-gold" />
            <span className="line-clamp-1">{property.location}</span>
          </div>

          {/* Specs */}
          <div className="flex items-center gap-4 text-gray text-sm mb-4">
            <div className="flex items-center gap-1">
              <Maximize2 className="w-4 h-4" />
              <span>{property.area} م²</span>
            </div>
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-1">
                <BedDouble className="w-4 h-4" />
                <span>{property.bedrooms}</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-1">
                <Bath className="w-4 h-4" />
                <span>{property.bathrooms}</span>
              </div>
            )}
          </div>

          {/* Price & CTA */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              <span className="text-xl font-bold text-gold">{property.price.toLocaleString("ar-EG")}</span>
              <span className="text-sm text-gray mr-1">{property.price_type}</span>
            </div>
            <span className="text-sm font-semibold text-charcoal hover:text-gold transition-colors duration-200">
              عرض التفاصيل
            </span>
          </div>
        </div>
      </div>
    </Link>
  )
}

function PropertyListCard({ property }: { property: Property }) {
  const isNew = new Date(property.created_at) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

  return (
    <Link href={`/properties/${property.id}`} className="block">
      <div className="card-3d group bg-card rounded-2xl overflow-hidden border border-border hover:border-gold/50 transition-all duration-300">
        <div className="flex flex-col sm:flex-row">
          {/* Image */}
          <div className="relative w-full sm:w-72 h-48 sm:h-auto flex-shrink-0">
            <Image
              src={property.images?.[0] || "/placeholder.svg?height=200&width=300&query=property"}
              alt={property.title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-500"
            />
            {/* Badges */}
            <div className="absolute top-4 right-4 flex gap-2">
              <span
                className={cn(
                  "px-3 py-1 rounded-full text-xs font-semibold",
                  property.type === "بيع" ? "bg-green text-beige" : "bg-gold text-charcoal",
                )}
              >
                {property.type}
              </span>
              {isNew && (
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-charcoal text-beige">جديد</span>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-4 mb-3">
                <h3 className="font-bold text-charcoal text-lg">{property.title}</h3>
                {property.status === "متاح" && (
                  <Badge className="bg-green/10 text-green border-green/20 flex-shrink-0">
                    <CheckCircle className="h-3 w-3 ml-1" />
                    متاح
                  </Badge>
                )}
              </div>

              <div className="flex items-center gap-1 text-gray text-sm mb-3">
                <MapPin className="w-4 h-4 text-gold" />
                <span>{property.location}</span>
              </div>

              <p className="text-gray text-sm line-clamp-2 mb-4">{property.description}</p>

              {/* Specs */}
              <div className="flex flex-wrap items-center gap-4 text-gray text-sm">
                <div className="flex items-center gap-1">
                  <Maximize2 className="w-4 h-4" />
                  <span>{property.area} م²</span>
                </div>
                {property.bedrooms > 0 && (
                  <div className="flex items-center gap-1">
                    <BedDouble className="w-4 h-4" />
                    <span>{property.bedrooms} غرف</span>
                  </div>
                )}
                {property.bathrooms > 0 && (
                  <div className="flex items-center gap-1">
                    <Bath className="w-4 h-4" />
                    <span>{property.bathrooms} حمام</span>
                  </div>
                )}
              </div>
            </div>

            {/* Price */}
            <div className="flex items-center justify-between pt-4 mt-4 border-t border-border">
              <div>
                <span className="text-2xl font-bold text-gold">{property.price.toLocaleString("ar-EG")}</span>
                <span className="text-sm text-gray mr-1">{property.price_type}</span>
              </div>
              <Button className="bg-charcoal hover:bg-charcoal-light text-beige">عرض التفاصيل</Button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}
