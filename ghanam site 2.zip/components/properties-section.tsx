"use client"

import Image from "next/image"
import Link from "next/link"
import { MapPin, Maximize2, BedDouble, Bath } from "lucide-react"
import { getAllProperties } from "@/lib/properties"
import ScrollReveal from "./scroll-reveal"

export default function PropertiesSection() {
  const properties = getAllProperties().slice(0, 4) // Show only first 4 on homepage

  return (
    <section id="properties" className="py-24 bg-beige-dark/50 relative">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <ScrollReveal>
          <div className="text-center mb-16">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">العقارات المتاحة</span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 text-balance">
              فرص عقارية حقيقية في وقتها الصح
            </h2>
            <p className="text-gray max-w-2xl mx-auto text-lg leading-relaxed">
              عقارات مختارة بعناية في أفضل مناطق المحلة الكبرى، بأسعار منافسة وفرص استثمارية مميزة.
            </p>
          </div>
        </ScrollReveal>

        {/* Properties Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {properties.map((property, index) => (
            <ScrollReveal key={property.id} delay={index * 100}>
              <div className="card-3d group bg-card rounded-2xl overflow-hidden border border-border hover:border-gold/50 transition-all duration-300 h-full">
                {/* Image Container - Use image field with fallback */}
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={
                      property.image ||
                      property.images?.[0] ||
                      "/placeholder.svg?height=400&width=600&query=real estate property"
                    }
                    alt={property.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {/* Type Badge */}
                  <div className="absolute top-4 right-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        property.type === "بيع" ? "bg-green text-beige" : "bg-gold text-charcoal"
                      }`}
                    >
                      {property.type}
                    </span>
                  </div>
                  {property.featured && (
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-charcoal text-beige">مميز</span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-bold text-charcoal mb-2 line-clamp-1">{property.title}</h3>

                  <div className="flex items-center gap-1 text-gray text-sm mb-4">
                    <MapPin className="w-4 h-4 text-gold" />
                    <span className="line-clamp-1">{property.location}</span>
                  </div>

                  {/* Specs */}
                  <div className="flex items-center gap-4 text-gray text-sm mb-4">
                    <div className="flex items-center gap-1">
                      <Maximize2 className="w-4 h-4" />
                      <span>{property.area} م²</span>
                    </div>
                    {property.bedrooms > 0 && (
                      <div className="flex items-center gap-1">
                        <BedDouble className="w-4 h-4" />
                        <span>{property.bedrooms}</span>
                      </div>
                    )}
                    {property.bathrooms > 0 && (
                      <div className="flex items-center gap-1">
                        <Bath className="w-4 h-4" />
                        <span>{property.bathrooms}</span>
                      </div>
                    )}
                  </div>

                  {/* Price & CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <span className="text-xl font-bold text-gold">{property.price}</span>
                      <span className="text-sm text-gray mr-1">{property.priceType}</span>
                    </div>
                    <Link
                      href={`https://wa.me/201011244308?text=استفسار عن: ${property.title}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm font-semibold text-charcoal hover:text-gold transition-colors duration-200"
                    >
                      استفسر الآن
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        {/* View All CTA */}
        <ScrollReveal delay={400}>
          <div className="text-center mt-12">
            <Link
              href="/properties"
              className="inline-flex items-center gap-2 bg-charcoal hover:bg-charcoal-light text-beige px-8 py-4 rounded-xl font-semibold transition-all duration-300 hover:shadow-lg glow-gold"
            >
              عرض كل العقارات
              <svg className="w-5 h-5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
