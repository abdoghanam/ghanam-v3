"use client"

import Image from "next/image"
import { CheckCircle, Users, Award, MapPin } from "lucide-react"

const highlights = [
  {
    icon: MapPin,
    title: "معرفة محلية عميقة",
    description: "نفهم سوق المحلة الكبرى بكل تفاصيله",
  },
  {
    icon: Users,
    title: "شبكة علاقات قوية",
    description: "نوصلك بالمشترين والبائعين الجادين",
  },
  {
    icon: Award,
    title: "ثقة وشفافية",
    description: "نتعامل بوضوح من أول لحظة",
  },
]

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side - Fixed image to use placeholder */}
          <div className="relative order-2 lg:order-1">
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
              <Image src="/professional-arab-real-estate-agent-in-modern-offi.jpg" alt="غنّام للعقارات" fill className="object-cover" />
              {/* Overlay card */}
              <div className="absolute bottom-6 right-6 left-6 bg-card/95 backdrop-blur-sm rounded-xl p-5 border border-gold/20">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="font-bold text-charcoal">عبدالرحمن غنام</p>
                    <p className="text-sm text-gray">المدير التنفيذي</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative badge */}
            <div className="absolute -top-4 -right-4 bg-gold text-charcoal px-6 py-3 rounded-xl font-bold shadow-lg">
              المحلة الكبرى
            </div>
          </div>

          {/* Content Side */}
          <div className="order-1 lg:order-2">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">من نحن</span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 leading-tight">
              السوق مش أرقام…
              <br />
              <span className="text-gold">السوق ناس</span>
            </h2>

            <p className="text-gray text-lg leading-relaxed mb-8">
              في غنّام للعقارات، نؤمن إن كل صفقة عقارية هي قصة. قصة عيلة بتدور على بيت، أو مستثمر بيدور على فرصة، أو صاحب
              عقار بيدور على المشتري الصح.
            </p>

            <p className="text-gray text-lg leading-relaxed mb-10">
              خبرتنا في سوق المحلة الكبرى مش بس أرقام ومتر مربع، دي فهم للناس واحتياجاتهم. نحن نربط الطرفين الصح ببعض،
              بشفافية وثقة.
            </p>

            {/* Highlights */}
            <div className="space-y-6">
              {highlights.map((item, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold/10 rounded-xl flex items-center justify-center shrink-0">
                    <item.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-bold text-charcoal mb-1">{item.title}</h3>
                    <p className="text-gray text-sm">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
