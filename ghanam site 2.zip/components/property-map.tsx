"use client"

import { MapPin } from "lucide-react"

interface PropertyMapProps {
  coordinates: { lat: number; lng: number }
  title: string
}

export default function PropertyMap({ coordinates, title }: PropertyMapProps) {
  const mapUrl = `https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${coordinates.lat},${coordinates.lng}&zoom=15&language=ar`

  const openInGoogleMaps = () => {
    window.open(`https://www.google.com/maps?q=${coordinates.lat},${coordinates.lng}`, "_blank")
  }

  return (
    <div className="space-y-4">
      <div className="relative rounded-2xl overflow-hidden bg-beige-dark h-[300px]">
        <iframe
          src={mapUrl}
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title={`موقع ${title}`}
        />
      </div>
      <button
        onClick={openInGoogleMaps}
        className="flex items-center gap-2 text-gold hover:text-gold-dark transition-colors font-medium"
      >
        <MapPin className="h-5 w-5" />
        فتح في خرائط جوجل
      </button>
    </div>
  )
}
