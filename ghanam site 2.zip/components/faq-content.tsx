"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import type { FAQ } from "@/lib/supabase/types"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, HelpCircle, MessageCircle, Phone, ChevronLeft } from "lucide-react"
import ScrollReveal from "./scroll-reveal"
import { cn } from "@/lib/utils"

interface FAQContentProps {
  faqs: FAQ[]
}

export default function FAQContent({ faqs }: FAQContentProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("الكل")

  // Get unique categories
  const categories = useMemo(() => {
    const cats = new Set(faqs.map((faq) => faq.category))
    return ["الكل", ...Array.from(cats)]
  }, [faqs])

  // Filter FAQs
  const filteredFAQs = useMemo(() => {
    return faqs.filter((faq) => {
      const matchesSearch =
        searchQuery === "" ||
        faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesCategory = activeCategory === "الكل" || faq.category === activeCategory

      return matchesSearch && matchesCategory
    })
  }, [faqs, searchQuery, activeCategory])

  return (
    <section className="pt-32 pb-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Page Header */}
        <ScrollReveal>
          <div className="text-center mb-12">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">مركز المساعدة</span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 text-balance">
              الأسئلة الشائعة
            </h1>
            <p className="text-gray max-w-2xl mx-auto text-lg leading-relaxed">
              إجابات على أكثر الأسئلة شيوعاً حول خدماتنا العقارية. لم تجد إجابتك؟ تواصل معنا مباشرة.
            </p>
          </div>
        </ScrollReveal>

        {/* Search & Filters */}
        <ScrollReveal delay={100}>
          <div className="max-w-3xl mx-auto mb-12">
            {/* Search */}
            <div className="relative mb-6">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray" />
              <Input
                type="text"
                placeholder="ابحث في الأسئلة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-12 h-14 text-lg"
              />
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap justify-center gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={cn(
                    "px-4 py-2 rounded-full font-medium transition-all duration-200",
                    activeCategory === category
                      ? "bg-gold text-charcoal"
                      : "bg-beige-dark text-gray hover:bg-beige hover:text-charcoal",
                  )}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* FAQs */}
        <ScrollReveal delay={200}>
          <div className="max-w-3xl mx-auto">
            {filteredFAQs.length > 0 ? (
              <Accordion type="single" collapsible className="space-y-4">
                {filteredFAQs.map((faq, index) => (
                  <AccordionItem
                    key={faq.id}
                    value={`faq-${faq.id}`}
                    className="bg-card border border-border rounded-xl px-6 data-[state=open]:border-gold/50"
                  >
                    <AccordionTrigger className="text-right hover:no-underline py-5 [&[data-state=open]>svg]:rotate-90">
                      <div className="flex items-start gap-3">
                        <HelpCircle className="h-5 w-5 text-gold flex-shrink-0 mt-0.5" />
                        <span className="font-semibold text-charcoal text-lg">{faq.question}</span>
                      </div>
                      <ChevronLeft className="h-5 w-5 text-gold flex-shrink-0 transition-transform duration-200" />
                    </AccordionTrigger>
                    <AccordionContent className="pr-8 pb-5">
                      <p className="text-gray leading-relaxed whitespace-pre-line">{faq.answer}</p>
                      <Badge variant="outline" className="mt-4 text-xs">
                        {faq.category}
                      </Badge>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            ) : (
              <div className="text-center py-16 bg-card rounded-2xl border border-border">
                <Search className="h-16 w-16 text-gray/30 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-charcoal mb-2">لا توجد نتائج</h3>
                <p className="text-gray mb-6">جرب البحث بكلمات مختلفة أو تصفح الفئات</p>
              </div>
            )}
          </div>
        </ScrollReveal>

        {/* Contact CTA */}
        <ScrollReveal delay={300}>
          <div className="max-w-3xl mx-auto mt-16">
            <div className="bg-charcoal rounded-3xl p-8 lg:p-12 text-center">
              <h2 className="text-2xl lg:text-3xl font-bold text-beige mb-4">لم تجد إجابتك؟</h2>
              <p className="text-beige/70 mb-8 max-w-lg mx-auto">
                فريقنا جاهز للإجابة على جميع استفساراتك. تواصل معنا الآن وسنرد عليك في أقرب وقت.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link
                  href="https://wa.me/201011244308?text=لدي استفسار عن خدماتكم"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-3 bg-gold hover:bg-gold-light text-charcoal px-8 py-4 rounded-xl font-bold transition-all duration-300"
                >
                  <MessageCircle className="w-5 h-5" />
                  واتساب
                </Link>
                <Link
                  href="tel:+201011244308"
                  className="inline-flex items-center justify-center gap-3 bg-transparent border-2 border-beige/30 hover:border-gold text-beige hover:text-gold px-8 py-4 rounded-xl font-bold transition-all duration-300"
                >
                  <Phone className="w-5 h-5" />
                  اتصل بنا
                </Link>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
