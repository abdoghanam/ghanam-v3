"use client"

import { useRef, useEffect, useState } from "react"
import Image from "next/image"

interface Logo3DProps {
  size?: "sm" | "md" | "lg" | "xl"
  className?: string
  showText?: boolean
}

export default function Logo3D({ size = "md", className = "", showText = true }: Logo3DProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [rotation, setRotation] = useState({ x: 0, y: 0 })
  const [isHovered, setIsHovered] = useState(false)

  const sizes = {
    sm: { width: 40, height: 40 },
    md: { width: 60, height: 60 },
    lg: { width: 100, height: 100 },
    xl: { width: 150, height: 150 },
  }

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const handleMouseMove = (e: MouseEvent) => {
      if (!isHovered) return
      const rect = container.getBoundingClientRect()
      const centerX = rect.left + rect.width / 2
      const centerY = rect.top + rect.height / 2
      const rotateX = ((e.clientY - centerY) / rect.height) * 20
      const rotateY = ((e.clientX - centerX) / rect.width) * -20
      setRotation({ x: rotateX, y: rotateY })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [isHovered])

  return (
    <div
      ref={containerRef}
      className={`relative inline-flex items-center gap-3 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false)
        setRotation({ x: 0, y: 0 })
      }}
      style={{ perspective: "1000px" }}
    >
      {/* 3D Logo Container */}
      <div
        className="relative transition-transform duration-300 ease-out"
        style={{
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
          transformStyle: "preserve-3d",
        }}
      >
        {/* Glow Effect */}
        <div
          className="absolute inset-0 blur-xl opacity-50 transition-opacity duration-300"
          style={{
            background: "radial-gradient(circle, rgba(198, 166, 93, 0.6) 0%, transparent 70%)",
            transform: "translateZ(-20px) scale(1.5)",
            opacity: isHovered ? 0.8 : 0.4,
          }}
        />

        {/* Shadow Layer */}
        <div
          className="absolute inset-0 transition-all duration-300"
          style={{
            transform: `translateZ(-10px) translateX(${rotation.y * 0.3}px) translateY(${rotation.x * 0.3}px)`,
            filter: "blur(8px)",
            opacity: 0.3,
          }}
        >
          <Image
            src="/ghanam-logo.png"
            alt=""
            width={sizes[size].width}
            height={sizes[size].height}
            className="object-contain brightness-0"
          />
        </div>

        {/* Main Logo */}
        <div
          className="relative transition-all duration-300"
          style={{
            transform: isHovered ? "translateZ(20px)" : "translateZ(0)",
          }}
        >
          <Image
            src="/ghanam-logo.png"
            alt="غنّام للعقارات"
            width={sizes[size].width}
            height={sizes[size].height}
            className="object-contain drop-shadow-2xl"
            priority
          />
        </div>

        {/* Shine Effect */}
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            background: `linear-gradient(${135 + rotation.y * 2}deg, rgba(255,255,255,0.3) 0%, transparent 50%)`,
            transform: "translateZ(25px)",
            opacity: isHovered ? 1 : 0,
            borderRadius: "8px",
          }}
        />
      </div>

      {/* Text beside logo */}
      {showText && (
        <div
          className="flex flex-col transition-transform duration-300"
          style={{
            transform: isHovered ? "translateX(5px)" : "translateX(0)",
          }}
        >
          <span className="text-lg md:text-xl font-bold text-gold">غنّام</span>
          <span className="text-xs text-muted-foreground">للعقارات</span>
        </div>
      )}
    </div>
  )
}
