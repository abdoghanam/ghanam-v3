"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Send,
  CheckCircle,
  Loader2,
  Mail,
  Facebook,
  Instagram,
} from "lucide-react"
import ScrollReveal from "./scroll-reveal"
import { submitInquiryAction } from "@/app/actions/inquiries"

const inquiryTypes = [
  { value: "buy", label: "أريد شراء عقار" },
  { value: "sell", label: "أريد بيع عقار" },
  { value: "rent", label: "أريد إيجار عقار" },
  { value: "valuation", label: "تقييم عقار" },
  { value: "consultation", label: "استشارة عقارية" },
  { value: "other", label: "استفسار آخر" },
]

export default function ContactPageContent() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    inquiryType: "",
    message: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    const inquiryTypeLabel = inquiryTypes.find((t) => t.value === formData.inquiryType)?.label || ""
    const fullMessage = `نوع الاستفسار: ${inquiryTypeLabel}\n\n${formData.message}`

    const result = await submitInquiryAction({
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      message: fullMessage,
    })

    setIsSubmitting(false)

    if (result.success) {
      setIsSubmitted(true)
    } else {
      setError(result.error || "حدث خطأ أثناء إرسال الرسالة")
    }
  }

  return (
    <section className="pt-32 pb-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Page Header */}
        <ScrollReveal>
          <div className="text-center mb-16">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">نحن هنا لمساعدتك</span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-charcoal mb-6 text-balance">تواصل معنا</h1>
            <p className="text-gray max-w-2xl mx-auto text-lg leading-relaxed">
              سواء كنت تبحث عن عقار أو تريد بيع عقارك، فريقنا جاهز لمساعدتك. اختر الطريقة المناسبة للتواصل.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <ScrollReveal delay={100}>
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-charcoal mb-6">معلومات التواصل</h2>
                <div className="space-y-4">
                  {/* Phone */}
                  <Card className="border-border hover:border-gold/50 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center">
                          <Phone className="w-7 h-7 text-gold" />
                        </div>
                        <div>
                          <h3 className="font-bold text-charcoal mb-1">اتصل بنا</h3>
                          <a
                            href="tel:+201011244308"
                            className="text-gold hover:text-gold-dark font-semibold text-lg transition-colors"
                            dir="ltr"
                          >
                            01011244308
                          </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* WhatsApp */}
                  <Card className="border-border hover:border-gold/50 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-green/10 rounded-xl flex items-center justify-center">
                          <MessageCircle className="w-7 h-7 text-green" />
                        </div>
                        <div>
                          <h3 className="font-bold text-charcoal mb-1">واتساب</h3>
                          <Link
                            href="https://wa.me/201011244308"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-green hover:text-green-dark font-semibold text-lg transition-colors"
                          >
                            تواصل الآن
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Location */}
                  <Card className="border-border hover:border-gold/50 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center">
                          <MapPin className="w-7 h-7 text-gold" />
                        </div>
                        <div>
                          <h3 className="font-bold text-charcoal mb-1">الموقع</h3>
                          <p className="text-gray">المحلة الكبرى، محافظة الغربية، مصر</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Working Hours */}
                  <Card className="border-border hover:border-gold/50 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center">
                          <Clock className="w-7 h-7 text-gold" />
                        </div>
                        <div>
                          <h3 className="font-bold text-charcoal mb-1">مواعيد العمل</h3>
                          <p className="text-gray">السبت - الخميس: 9 صباحاً - 9 مساءً</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Social Media */}
              <div>
                <h3 className="font-bold text-charcoal mb-4">تابعنا على</h3>
                <div className="flex gap-4">
                  <Link
                    href="https://facebook.com/ghanamrealestate"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-beige-dark hover:bg-gold/10 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <Facebook className="w-6 h-6 text-charcoal" />
                  </Link>
                  <Link
                    href="https://instagram.com/ghanamrealestate"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-beige-dark hover:bg-gold/10 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <Instagram className="w-6 h-6 text-charcoal" />
                  </Link>
                  <Link
                    href="https://tiktok.com/@ghanamrealestate"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-beige-dark hover:bg-gold/10 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <svg className="w-6 h-6 text-charcoal" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                    </svg>
                  </Link>
                </div>
              </div>

              {/* Map */}
              <div className="rounded-2xl overflow-hidden h-[250px]">
                <iframe
                  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=المحلة+الكبرى،+الغربية،+مصر&zoom=13&language=ar"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="موقع غنّام للعقارات"
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Contact Form */}
          <ScrollReveal delay={200}>
            <Card className="border-gold/20">
              <CardContent className="p-8">
                {isSubmitted ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 bg-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="h-10 w-10 text-green" />
                    </div>
                    <h3 className="text-2xl font-bold text-charcoal mb-4">تم إرسال رسالتك بنجاح</h3>
                    <p className="text-gray mb-8">شكراً لتواصلك معنا. سنرد عليك في أقرب وقت ممكن.</p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                      <Button onClick={() => setIsSubmitted(false)} variant="outline" className="gap-2 bg-transparent">
                        <Mail className="h-4 w-4" />
                        إرسال رسالة أخرى
                      </Button>
                      <Button asChild className="bg-green hover:bg-green-light text-white gap-2">
                        <Link href="https://wa.me/201011244308" target="_blank" rel="noopener noreferrer">
                          <MessageCircle className="h-4 w-4" />
                          واتساب للرد الفوري
                        </Link>
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h2 className="text-2xl font-bold text-charcoal mb-6">أرسل رسالتك</h2>
                    <form onSubmit={handleSubmit} className="space-y-5">
                      {error && (
                        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">{error}</div>
                      )}

                      <div className="grid sm:grid-cols-2 gap-5">
                        <div className="space-y-2">
                          <Label htmlFor="name">الاسم *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            placeholder="اسمك الكريم"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">رقم الهاتف *</Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            placeholder="01xxxxxxxxx"
                            required
                            dir="ltr"
                            className="text-left"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">البريد الإلكتروني (اختياري)</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="example@email.com"
                          dir="ltr"
                          className="text-left"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="inquiryType">نوع الاستفسار *</Label>
                        <Select
                          value={formData.inquiryType}
                          onValueChange={(value) => setFormData({ ...formData, inquiryType: value })}
                          required
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="اختر نوع الاستفسار" />
                          </SelectTrigger>
                          <SelectContent>
                            {inquiryTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message">رسالتك *</Label>
                        <Textarea
                          id="message"
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          placeholder="اكتب رسالتك بالتفصيل..."
                          rows={5}
                          required
                        />
                      </div>

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gold hover:bg-gold-dark text-charcoal h-12 text-lg gap-2"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="h-5 w-5 animate-spin" />
                            جاري الإرسال...
                          </>
                        ) : (
                          <>
                            <Send className="h-5 w-5" />
                            إرسال الرسالة
                          </>
                        )}
                      </Button>
                    </form>
                  </>
                )}
              </CardContent>
            </Card>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
