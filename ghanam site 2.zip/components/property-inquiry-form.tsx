"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Send, MessageCircle, CheckCircle, Loader2 } from "lucide-react"
import { submitInquiryAction } from "@/app/actions/inquiries"

interface PropertyInquiryFormProps {
  propertyTitle?: string
  propertyId?: number
}

export default function PropertyInquiryForm({ propertyTitle, propertyId }: PropertyInquiryFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    message: propertyTitle ? `أرغب في الاستفسار عن: ${propertyTitle}` : "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    const result = await submitInquiryAction({
      ...formData,
      property_id: propertyId,
      property_title: propertyTitle,
    })

    setIsSubmitting(false)

    if (result.success) {
      setIsSubmitted(true)
    } else {
      setError(result.error || "حدث خطأ أثناء إرسال الاستفسار")
    }
  }

  const handleWhatsAppInquiry = () => {
    const message = propertyTitle
      ? `مرحباً، أرغب في الاستفسار عن العقار: ${propertyTitle}\nاسمي: ${formData.name}\nرقمي: ${formData.phone}`
      : `مرحباً، أرغب في الاستفسار عن العقارات المتاحة\nاسمي: ${formData.name}\nرقمي: ${formData.phone}`
    window.open(`https://wa.me/201011244308?text=${encodeURIComponent(message)}`, "_blank")
  }

  if (isSubmitted) {
    return (
      <Card className="border-gold/20 bg-green/5">
        <CardContent className="pt-6 text-center">
          <CheckCircle className="h-12 w-12 text-green mx-auto mb-4" />
          <h3 className="text-xl font-bold text-charcoal mb-2">تم إرسال استفسارك بنجاح</h3>
          <p className="text-gray mb-4">سنتواصل معك في أقرب وقت ممكن</p>
          <Button onClick={handleWhatsAppInquiry} className="bg-green hover:bg-green-light text-white gap-2">
            <MessageCircle className="h-4 w-4" />
            تواصل عبر واتساب للرد الفوري
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-gold/20">
      <CardHeader>
        <CardTitle className="text-xl text-charcoal">أرسل استفسارك</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">{error}</div>}
          <div className="space-y-2">
            <Label htmlFor="name">الاسم *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="اسمك الكريم"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف *</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="01xxxxxxxxx"
              required
              dir="ltr"
              className="text-left"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني (اختياري)</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="example@email.com"
              dir="ltr"
              className="text-left"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">رسالتك</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="اكتب استفسارك هنا..."
              rows={4}
            />
          </div>
          <div className="flex flex-col gap-3">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gold hover:bg-gold-dark text-charcoal gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  إرسال الاستفسار
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleWhatsAppInquiry}
              className="w-full border-green text-green hover:bg-green hover:text-white gap-2 bg-transparent"
            >
              <MessageCircle className="h-4 w-4" />
              تواصل مباشر عبر واتساب
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
