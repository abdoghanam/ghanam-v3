"use client"

import { useState } from "react"
import { Share2, Facebook, Link2, Check, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface PropertyShareProps {
  title: string
  url: string
}

export default function PropertyShare({ title, url }: PropertyShareProps) {
  const [copied, setCopied] = useState(false)

  const shareUrl = typeof window !== "undefined" ? window.location.origin + url : url

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(shareUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleWhatsAppShare = () => {
    const text = `شاهد هذا العقار: ${title}\n${shareUrl}`
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank")
  }

  const handleFacebookShare = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, "_blank")
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          <Share2 className="h-4 w-4" />
          مشاركة
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={handleWhatsAppShare} className="gap-3 cursor-pointer">
          <MessageCircle className="h-4 w-4 text-green-600" />
          واتساب
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleFacebookShare} className="gap-3 cursor-pointer">
          <Facebook className="h-4 w-4 text-blue-600" />
          فيسبوك
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleCopyLink} className="gap-3 cursor-pointer">
          {copied ? (
            <>
              <Check className="h-4 w-4 text-green-600" />
              تم النسخ
            </>
          ) : (
            <>
              <Link2 className="h-4 w-4" />
              نسخ الرابط
            </>
          )}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
