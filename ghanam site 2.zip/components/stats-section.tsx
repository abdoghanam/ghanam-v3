"use client"

import { useEffect, useState, useRef } from "react"
import { Building2, Users, Award, MapPin } from "lucide-react"
import ScrollReveal from "./scroll-reveal"

function AnimatedCounter({ end, duration = 2000 }: { end: number; duration?: number }) {
  const [count, setCount] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.5 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return

    let startTime: number
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / duration, 1)
      setCount(Math.floor(progress * end))
      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }
    requestAnimationFrame(animate)
  }, [isVisible, end, duration])

  return <span ref={ref}>{count}+</span>
}

const stats = [
  {
    icon: Award,
    value: 15,
    label: "سنة خبرة",
    description: "في سوق المحلة الكبرى",
  },
  {
    icon: Building2,
    value: 500,
    label: "عقار تم بيعه",
    description: "صفقات ناجحة",
  },
  {
    icon: Users,
    value: 350,
    label: "عميل سعيد",
    description: "ثقة متجددة",
  },
  {
    icon: MapPin,
    value: 12,
    label: "منطقة نغطيها",
    description: "في المحلة الكبرى",
  },
]

export default function StatsSection() {
  return (
    <section className="py-20 bg-charcoal relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <ScrollReveal>
          <div className="text-center mb-12">
            <span className="inline-block text-gold font-semibold text-sm mb-4 tracking-wider">أرقامنا تتكلم</span>
            <h2 className="text-3xl md:text-4xl font-bold text-beige mb-4 text-balance">خبرة طويلة ونتائج ملموسة</h2>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {stats.map((stat, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <div className="card-3d text-center p-6 lg:p-8 bg-charcoal-light/50 rounded-2xl border border-gold/10 hover:border-gold/30 transition-colors duration-300">
                <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-7 h-7 text-gold" />
                </div>
                <div className="text-4xl lg:text-5xl font-bold text-gold mb-2 animate-count">
                  <AnimatedCounter end={stat.value} />
                </div>
                <div className="text-beige font-semibold mb-1">{stat.label}</div>
                <div className="text-gray text-sm">{stat.description}</div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
