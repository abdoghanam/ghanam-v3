"use client"

import Image from "next/image"
import Link from "next/link"
import type { Property } from "@/lib/supabase/types"
import { MapPin, Maximize2, BedDouble, Bath, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import ScrollReveal from "./scroll-reveal"

interface SimilarPropertiesProps {
  properties: Property[]
  currentPropertyId: number
}

export default function SimilarProperties({ properties, currentPropertyId }: SimilarPropertiesProps) {
  const filteredProperties = properties.filter((p) => p.id !== currentPropertyId)

  if (filteredProperties.length === 0) return null

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-charcoal">عقارات مشابهة</h2>
        <Link href="/properties" className="text-gold hover:text-gold-dark font-medium transition-colors">
          عرض المزيد
        </Link>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {filteredProperties.map((property, index) => (
          <ScrollReveal key={property.id} delay={index * 100}>
            <Link href={`/properties/${property.id}`} className="block h-full">
              <div className="card-3d group bg-card rounded-2xl overflow-hidden border border-border hover:border-gold/50 transition-all duration-300 h-full">
                {/* Image Container */}
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={property.images?.[0] || "/placeholder.svg?height=200&width=300&query=property"}
                    alt={property.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {/* Badge */}
                  <div className="absolute top-4 right-4">
                    <span
                      className={cn(
                        "px-3 py-1 rounded-full text-xs font-semibold",
                        property.type === "بيع" ? "bg-green text-beige" : "bg-gold text-charcoal",
                      )}
                    >
                      {property.type}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className="font-bold text-charcoal mb-2 line-clamp-1">{property.title}</h3>

                  <div className="flex items-center gap-1 text-gray text-sm mb-3">
                    <MapPin className="w-4 h-4 text-gold" />
                    <span className="line-clamp-1">{property.location}</span>
                  </div>

                  {/* Specs */}
                  <div className="flex items-center gap-3 text-gray text-sm mb-3">
                    <div className="flex items-center gap-1">
                      <Maximize2 className="w-4 h-4" />
                      <span>{property.area} م²</span>
                    </div>
                    {property.bedrooms > 0 && (
                      <div className="flex items-center gap-1">
                        <BedDouble className="w-4 h-4" />
                        <span>{property.bedrooms}</span>
                      </div>
                    )}
                    {property.bathrooms > 0 && (
                      <div className="flex items-center gap-1">
                        <Bath className="w-4 h-4" />
                        <span>{property.bathrooms}</span>
                      </div>
                    )}
                  </div>

                  {/* Price */}
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <div>
                      <span className="text-lg font-bold text-gold">{property.price.toLocaleString("ar-EG")}</span>
                      <span className="text-xs text-gray mr-1">{property.price_type}</span>
                    </div>
                    {property.status === "متاح" && (
                      <span className="text-xs text-green flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        متاح
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </Link>
          </ScrollReveal>
        ))}
      </div>
    </div>
  )
}
