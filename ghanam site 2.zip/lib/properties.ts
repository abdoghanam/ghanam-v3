import propertiesData from "@/data/properties.json"

export type Property = {
  id: number
  title: string
  location: string
  price: string
  priceType: string
  type: string
  category: string
  area: number
  bedrooms: number
  bathrooms: number
  floor: number
  totalFloors: number
  yearBuilt: number
  status: string
  image?: string // Added image field
  images: string[]
  featured: boolean
  description: string
  features: string[]
  coordinates: { lat: number; lng: number }
  createdAt: string
}

export type Testimonial = {
  id: number
  name: string
  role: string
  content: string
  rating: number
}

export type Stats = {
  yearsExperience: number
  propertiesSold: number
  happyClients: number
  areasServed: number
}

export type CompanyInfo = {
  name: string
  nameEn: string
  slogan: string
  phone: string
  whatsapp: string
  email: string
  address: string
  socialMedia: {
    facebook: string
    instagram: string
    tiktok: string
  }
  workingHours: string
}

export function getAllProperties(): Property[] {
  return propertiesData.properties as Property[]
}

export function getFeaturedProperties(): Property[] {
  return (propertiesData.properties as Property[]).filter((p) => p.featured)
}

export function getPropertyById(id: number): Property | undefined {
  return (propertiesData.properties as Property[]).find((p) => p.id === id)
}

export function getPropertiesByType(type: string): Property[] {
  return (propertiesData.properties as Property[]).filter((p) => p.type === type)
}

export function getPropertiesByCategory(category: string): Property[] {
  return (propertiesData.properties as Property[]).filter((p) => p.category === category)
}

export function searchProperties(query: string): Property[] {
  const lowerQuery = query.toLowerCase()
  return (propertiesData.properties as Property[]).filter(
    (p) =>
      p.title.toLowerCase().includes(lowerQuery) ||
      p.location.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery),
  )
}

export function filterProperties(filters: {
  type?: string
  category?: string
  minPrice?: number
  maxPrice?: number
  minArea?: number
  maxArea?: number
  bedrooms?: number
}): Property[] {
  return (propertiesData.properties as Property[]).filter((p) => {
    if (filters.type && p.type !== filters.type) return false
    if (filters.category && p.category !== filters.category) return false
    if (filters.minPrice && Number.parseFloat(p.price.replace(/,/g, "")) < filters.minPrice) return false
    if (filters.maxPrice && Number.parseFloat(p.price.replace(/,/g, "")) > filters.maxPrice) return false
    if (filters.minArea && p.area < filters.minArea) return false
    if (filters.maxArea && p.area > filters.maxArea) return false
    if (filters.bedrooms && p.bedrooms !== filters.bedrooms) return false
    return true
  })
}

export function getStats(): Stats {
  return propertiesData.stats
}

export function getTestimonials(): Testimonial[] {
  return propertiesData.testimonials
}

export function getCompanyInfo(): CompanyInfo {
  return propertiesData.companyInfo
}

export function getCategories(): string[] {
  const categories = new Set((propertiesData.properties as Property[]).map((p) => p.category))
  return Array.from(categories)
}

export function getTypes(): string[] {
  const types = new Set((propertiesData.properties as Property[]).map((p) => p.type))
  return Array.from(types)
}
