export type Property = {
  id: number
  title: string
  location: string
  price: number
  price_type: string
  type: "بيع" | "إيجار" | "بدل"
  category: "شقة" | "فيلا" | "تجاري" | "أرض" | "مكتب"
  area: number
  bedrooms: number
  bathrooms: number
  floor: number
  total_floors: number
  year_built: number
  status: "متاح" | "محجوز" | "مباع"
  images: string[]
  featured: boolean
  description: string
  features: string[]
  coordinates: { lat: number; lng: number }
  created_at: string
  updated_at: string
}

export type Inquiry = {
  id: number
  name: string
  phone: string
  email: string | null
  message: string | null
  property_id: number | null
  property_title: string | null
  status: "جديد" | "تم الرد" | "مغلق"
  created_at: string
}

export type FAQ = {
  id: number
  question: string
  answer: string
  category: string
  order_index: number
  is_active: boolean
  created_at: string
}

export type PropertyFilters = {
  search?: string
  type?: string
  category?: string
  bedrooms?: string
  minPrice?: number
  maxPrice?: number
  minArea?: number
  maxArea?: number
  sortBy?: "newest" | "price-asc" | "price-desc" | "area-desc"
}

export type Admin = {
  id: string
  email: string
  name: string
  role: "admin" | "super_admin"
  avatar_url: string | null
  is_active: boolean
  last_login: string | null
  created_at: string
  updated_at: string
}

export type SiteSetting = {
  id: number
  key: string
  value: string | null
  type: "text" | "number" | "boolean" | "json" | "image"
  category: string
  label: string | null
  description: string | null
  updated_at: string
}

export type ActivityLog = {
  id: number
  admin_id: string | null
  admin_email: string | null
  action: string
  entity_type: string | null
  entity_id: number | null
  details: Record<string, unknown> | null
  ip_address: string | null
  created_at: string
}

export type Testimonial = {
  id: number
  name: string
  role: string | null
  content: string
  rating: number
  avatar_url: string | null
  is_active: boolean
  order_index: number
  created_at: string
}

export type Service = {
  id: number
  title: string
  description: string | null
  icon: string | null
  is_active: boolean
  order_index: number
  created_at: string
}

export type DashboardStats = {
  totalProperties: number
  availableProperties: number
  soldProperties: number
  rentedProperties: number
  totalInquiries: number
  newInquiries: number
  totalViews: number
  recentInquiries: Inquiry[]
  propertiesByType: { type: string; count: number }[]
  propertiesByCategory: { category: string; count: number }[]
  monthlyInquiries: { month: string; count: number }[]
}
