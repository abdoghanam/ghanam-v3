import { createClient } from "./server"
import type { FAQ } from "./types"

export async function getFAQs(): Promise<FAQ[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("faqs")
    .select("*")
    .eq("is_active", true)
    .order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching FAQs:", error)
    return []
  }

  return data || []
}

export async function getFAQsByCategory(category: string): Promise<FAQ[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("faqs")
    .select("*")
    .eq("category", category)
    .eq("is_active", true)
    .order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching FAQs by category:", error)
    return []
  }

  return data || []
}
