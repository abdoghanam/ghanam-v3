import { createClient, isSupabaseConfigured } from "./server"
import type { Property, PropertyFilters } from "./types"

export async function getProperties(filters?: PropertyFilters): Promise<Property[]> {
  if (!isSupabaseConfigured()) {
    return []
  }

  const supabase = await createClient()
  if (!supabase) return []

  let query = supabase.from("properties").select("*")

  // Apply filters
  if (filters?.type && filters.type !== "الكل") {
    query = query.eq("type", filters.type)
  }

  if (filters?.category && filters.category !== "الكل") {
    query = query.eq("category", filters.category)
  }

  if (filters?.bedrooms && filters.bedrooms !== "الكل") {
    if (filters.bedrooms === "5+") {
      query = query.gte("bedrooms", 5)
    } else {
      query = query.eq("bedrooms", Number.parseInt(filters.bedrooms))
    }
  }

  if (filters?.minPrice) {
    query = query.gte("price", filters.minPrice)
  }

  if (filters?.maxPrice) {
    query = query.lte("price", filters.maxPrice)
  }

  if (filters?.minArea) {
    query = query.gte("area", filters.minArea)
  }

  if (filters?.maxArea) {
    query = query.lte("area", filters.maxArea)
  }

  if (filters?.search) {
    query = query.or(
      `title.ilike.%${filters.search}%,location.ilike.%${filters.search}%,description.ilike.%${filters.search}%`,
    )
  }

  // Apply sorting
  switch (filters?.sortBy) {
    case "price-asc":
      query = query.order("price", { ascending: true })
      break
    case "price-desc":
      query = query.order("price", { ascending: false })
      break
    case "area-desc":
      query = query.order("area", { ascending: false })
      break
    case "newest":
    default:
      query = query.order("created_at", { ascending: false })
      break
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching properties:", error)
    return []
  }

  return data || []
}

export async function getPropertyById(id: number): Promise<Property | null> {
  if (!isSupabaseConfigured()) {
    return null
  }

  const supabase = await createClient()
  if (!supabase) return null

  const { data, error } = await supabase.from("properties").select("*").eq("id", id).single()

  if (error) {
    console.error("Error fetching property:", error)
    return null
  }

  return data
}

export async function getFeaturedProperties(): Promise<Property[]> {
  if (!isSupabaseConfigured()) {
    return []
  }

  const supabase = await createClient()
  if (!supabase) return []

  const { data, error } = await supabase
    .from("properties")
    .select("*")
    .eq("featured", true)
    .order("created_at", { ascending: false })
    .limit(4)

  if (error) {
    console.error("Error fetching featured properties:", error)
    return []
  }

  return data || []
}

export async function getSimilarProperties(property: Property, limit = 3): Promise<Property[]> {
  if (!isSupabaseConfigured()) {
    return []
  }

  const supabase = await createClient()
  if (!supabase) return []

  const { data, error } = await supabase
    .from("properties")
    .select("*")
    .eq("category", property.category)
    .neq("id", property.id)
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error fetching similar properties:", error)
    return []
  }

  return data || []
}
