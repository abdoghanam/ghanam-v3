import { createClient } from "./client"

export async function submitInquiry(inquiry: {
  name: string
  phone: string
  email?: string
  message?: string
  property_id?: number
  property_title?: string
}): Promise<{ success: boolean; error?: string }> {
  const supabase = createClient()

  const { error } = await supabase.from("inquiries").insert([inquiry])

  if (error) {
    console.error("Error submitting inquiry:", error)
    return { success: false, error: error.message }
  }

  return { success: true }
}
