-- Create properties table
CREATE TABLE IF NOT EXISTS properties (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  location VARCHAR(255) NOT NULL,
  price DECIMAL(12, 2) NOT NULL,
  price_type VARCHAR(50) NOT NULL DEFAULT 'جنيه',
  type VARCHAR(50) NOT NULL CHECK (type IN ('بيع', 'إيجار', 'بدل')),
  category VARCHAR(50) NOT NULL CHECK (category IN ('شقة', 'فيلا', 'تجاري', 'أرض', 'مكتب')),
  area INTEGER NOT NULL,
  bedrooms INTEGER DEFAULT 0,
  bathrooms INTEGER DEFAULT 0,
  floor INTEGER DEFAULT 0,
  total_floors INTEGER DEFAULT 0,
  year_built INTEGER DEFAULT 0,
  status VARCHAR(50) NOT NULL DEFAULT 'متاح' CHECK (status IN ('متاح', 'محجوز', 'مباع')),
  images TEXT[] DEFAULT ARRAY[]::TEXT[],
  featured BOOLEAN DEFAULT FALSE,
  description TEXT,
  features TEXT[] DEFAULT ARRAY[]::TEXT[],
  coordinates JSONB DEFAULT '{"lat": 0, "lng": 0}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create inquiries table for contact form submissions
CREATE TABLE IF NOT EXISTS inquiries (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  email VARCHAR(255),
  message TEXT,
  property_id INTEGER REFERENCES properties(id) ON DELETE SET NULL,
  property_title VARCHAR(255),
  status VARCHAR(50) DEFAULT 'جديد' CHECK (status IN ('جديد', 'تم الرد', 'مغلق')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create FAQs table
CREATE TABLE IF NOT EXISTS faqs (
  id SERIAL PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category VARCHAR(100) DEFAULT 'عام',
  order_index INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_properties_type ON properties(type);
CREATE INDEX IF NOT EXISTS idx_properties_category ON properties(category);
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_featured ON properties(featured);
CREATE INDEX IF NOT EXISTS idx_properties_price ON properties(price);
CREATE INDEX IF NOT EXISTS idx_properties_area ON properties(area);
CREATE INDEX IF NOT EXISTS idx_properties_created_at ON properties(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inquiries_status ON inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_created_at ON inquiries(created_at DESC);

-- Enable Row Level Security
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access to properties
CREATE POLICY "Properties are viewable by everyone" ON properties
  FOR SELECT USING (true);

-- Create policies for public read access to FAQs
CREATE POLICY "FAQs are viewable by everyone" ON faqs
  FOR SELECT USING (is_active = true);

-- Create policy for inserting inquiries (anyone can submit)
CREATE POLICY "Anyone can submit inquiries" ON inquiries
  FOR INSERT WITH CHECK (true);

-- Create policy for reading inquiries (only authenticated users - for admin)
CREATE POLICY "Inquiries viewable by authenticated users" ON inquiries
  FOR SELECT USING (auth.role() = 'authenticated');
