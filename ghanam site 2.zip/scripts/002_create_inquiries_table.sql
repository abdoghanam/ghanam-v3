-- Create inquiries table for customer messages
CREATE TABLE IF NOT EXISTS inquiries (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  message TEXT,
  property_id INTEGER REFERENCES properties(id) ON DELETE SET NULL,
  property_title TEXT,
  status TEXT DEFAULT 'جديد' CHECK (status IN ('جديد', 'تم الرد', 'مغلق')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;

-- Allow public to insert inquiries
CREATE POLICY "Allow public insert" ON inquiries
  FOR INSERT WITH CHECK (true);

-- Allow authenticated users to read/update/delete
CREATE POLICY "Allow authenticated read" ON inquiries
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated update" ON inquiries
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated delete" ON inquiries
  FOR DELETE TO authenticated USING (true);
