-- Create settings table for site configuration
CREATE TABLE IF NOT EXISTS settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read" ON settings
  FOR SELECT USING (true);

-- Allow authenticated users to update
CREATE POLICY "Allow authenticated update" ON settings
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated insert" ON settings
  FOR INSERT TO authenticated WITH CHECK (true);

-- Insert default settings
INSERT INTO settings (key, value) VALUES
  ('site_info', '{"name": "غنّام للعقارات", "phone": "201011244308", "email": "info@ghanam.com", "address": "المحلة الكبرى، مصر"}'),
  ('social_links', '{"whatsapp": "201011244308", "facebook": "", "instagram": ""}')
ON CONFLICT (key) DO NOTHING;
