-- Create contacts table for customer inquiries
CREATE TABLE IF NOT EXISTS contacts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  message TEXT,
  property_id UUID REFERENCES properties(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'completed')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;

-- Allow public to insert contacts
CREATE POLICY "Allow public insert" ON contacts
  FOR INSERT WITH CHECK (true);

-- Allow authenticated users to read/update/delete
CREATE POLICY "Allow authenticated read" ON contacts
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated update" ON contacts
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated delete" ON contacts
  FOR DELETE TO authenticated USING (true);
