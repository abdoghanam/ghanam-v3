-- Create settings table for site configuration
CREATE TABLE IF NOT EXISTS site_settings (
  id SERIAL PRIMARY KEY,
  key TEXT UNIQUE NOT NULL,
  value TEXT,
  type TEXT DEFAULT 'text' CHECK (type IN ('text', 'number', 'boolean', 'json', 'image')),
  category TEXT DEFAULT 'general',
  label TEXT,
  description TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read" ON site_settings
  FOR SELECT USING (true);

-- Allow authenticated users to update
CREATE POLICY "Allow authenticated update" ON site_settings
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated insert" ON site_settings
  FOR INSERT TO authenticated WITH CHECK (true);

-- Insert default settings
INSERT INTO site_settings (key, value, type, category, label) VALUES
  ('site_name', 'غنّام للعقارات', 'text', 'general', 'اسم الموقع'),
  ('site_phone', '201011244308', 'text', 'contact', 'رقم الهاتف'),
  ('site_email', 'info@ghanam.com', 'text', 'contact', 'البريد الإلكتروني'),
  ('site_address', 'المحلة الكبرى، مصر', 'text', 'contact', 'العنوان'),
  ('whatsapp_number', '201011244308', 'text', 'social', 'رقم واتساب'),
  ('facebook_url', '', 'text', 'social', 'رابط فيسبوك'),
  ('instagram_url', '', 'text', 'social', 'رابط انستجرام')
ON CONFLICT (key) DO NOTHING;
