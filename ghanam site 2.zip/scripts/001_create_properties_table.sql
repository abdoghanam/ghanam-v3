-- Create properties table for real estate listings (matching TypeScript types)
CREATE TABLE IF NOT EXISTS properties (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  location TEXT NOT NULL,
  price NUMERIC NOT NULL,
  price_type TEXT DEFAULT 'جنيه',
  type TEXT NOT NULL CHECK (type IN ('بيع', 'إيجار', 'بدل')),
  category TEXT NOT NULL CHECK (category IN ('شقة', 'فيلا', 'تجاري', 'أرض', 'مكتب')),
  area NUMERIC NOT NULL,
  bedrooms INTEGER DEFAULT 0,
  bathrooms INTEGER DEFAULT 0,
  floor INTEGER DEFAULT 0,
  total_floors INTEGER DEFAULT 0,
  year_built INTEGER DEFAULT 2024,
  status TEXT DEFAULT 'متاح' CHECK (status IN ('متاح', 'محجوز', 'مباع')),
  images TEXT[] DEFAULT '{}',
  featured BOOLEAN DEFAULT false,
  description TEXT,
  features TEXT[] DEFAULT '{}',
  coordinates JSONB DEFAULT '{"lat": 30.9764, "lng": 31.1619}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_type ON properties(type);
CREATE INDEX IF NOT EXISTS idx_properties_category ON properties(category);
CREATE INDEX IF NOT EXISTS idx_properties_featured ON properties(featured);

-- Enable Row Level Security
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read access" ON properties
  FOR SELECT USING (true);

-- Allow authenticated users to insert/update/delete
CREATE POLICY "Allow authenticated insert" ON properties
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated update" ON properties
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated delete" ON properties
  FOR DELETE TO authenticated USING (true);
