-- Create admins table for admin users
CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin')),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create site_settings table for website configuration
CREATE TABLE IF NOT EXISTS site_settings (
  id SERIAL PRIMARY KEY,
  key VARCHAR(100) UNIQUE NOT NULL,
  value TEXT,
  type VARCHAR(50) DEFAULT 'text' CHECK (type IN ('text', 'number', 'boolean', 'json', 'image')),
  category VARCHAR(100) DEFAULT 'general',
  label VARCHAR(255),
  description TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create activity_logs table for tracking admin actions
CREATE TABLE IF NOT EXISTS activity_logs (
  id SERIAL PRIMARY KEY,
  admin_id UUID REFERENCES admins(id) ON DELETE SET NULL,
  admin_email VARCHAR(255),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id INTEGER,
  details JSONB,
  ip_address VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(255),
  content TEXT NOT NULL,
  rating INTEGER DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  icon VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default site settings
INSERT INTO site_settings (key, value, type, category, label, description) VALUES
  ('site_name', 'غنام للعقارات', 'text', 'general', 'اسم الموقع', 'اسم الشركة أو الموقع'),
  ('site_description', 'شريكك الموثوق في عالم العقارات', 'text', 'general', 'وصف الموقع', 'وصف قصير للموقع'),
  ('phone', '+201234567890', 'text', 'contact', 'رقم الهاتف', 'رقم الهاتف الرئيسي'),
  ('whatsapp', '+201234567890', 'text', 'contact', 'واتساب', 'رقم الواتساب'),
  ('email', 'info@ghanam.com', 'text', 'contact', 'البريد الإلكتروني', 'البريد الإلكتروني للتواصل'),
  ('address', 'القاهرة، مصر', 'text', 'contact', 'العنوان', 'عنوان المكتب'),
  ('facebook', '', 'text', 'social', 'فيسبوك', 'رابط صفحة الفيسبوك'),
  ('instagram', '', 'text', 'social', 'انستجرام', 'رابط حساب الانستجرام'),
  ('twitter', '', 'text', 'social', 'تويتر', 'رابط حساب تويتر'),
  ('youtube', '', 'text', 'social', 'يوتيوب', 'رابط قناة اليوتيوب'),
  ('hero_title', 'اكتشف منزل أحلامك', 'text', 'hero', 'عنوان الهيرو', 'العنوان الرئيسي في الصفحة الرئيسية'),
  ('hero_subtitle', 'نقدم لك أفضل العقارات بأفضل الأسعار مع خدمة متميزة', 'text', 'hero', 'العنوان الفرعي', 'النص الفرعي في الهيرو'),
  ('about_text', '', 'text', 'about', 'نص من نحن', 'نص قسم من نحن'),
  ('working_hours', 'السبت - الخميس: 9 ص - 9 م', 'text', 'contact', 'ساعات العمل', 'أوقات العمل'),
  ('logo_url', '', 'image', 'branding', 'الشعار', 'شعار الموقع'),
  ('map_coordinates', '{"lat": 30.0444, "lng": 31.2357}', 'json', 'contact', 'إحداثيات الخريطة', 'موقع المكتب على الخريطة')
ON CONFLICT (key) DO NOTHING;

-- Insert default testimonials
INSERT INTO testimonials (name, role, content, rating, is_active, order_index) VALUES
  ('أحمد محمد', 'مستثمر عقاري', 'تجربة ممتازة مع غنام للعقارات. الفريق محترف جداً وساعدني في إيجاد الشقة المثالية.', 5, true, 1),
  ('سارة أحمد', 'مالكة منزل', 'خدمة عملاء استثنائية. تم بيع عقاري في وقت قياسي وبسعر ممتاز.', 5, true, 2),
  ('محمد علي', 'رجل أعمال', 'أفضل شركة عقارات تعاملت معها. شفافية كاملة ومصداقية عالية.', 5, true, 3)
ON CONFLICT DO NOTHING;

-- Insert default services
INSERT INTO services (title, description, icon, is_active, order_index) VALUES
  ('بيع العقارات', 'نساعدك في بيع عقارك بأفضل سعر وفي أسرع وقت', 'building', true, 1),
  ('شراء العقارات', 'نوفر لك أفضل الخيارات العقارية التي تناسب احتياجاتك', 'home', true, 2),
  ('إيجار العقارات', 'خيارات إيجار متنوعة للشقق والفيلات والمكاتب', 'key', true, 3),
  ('الاستشارات العقارية', 'استشارات مجانية من خبراء العقارات لمساعدتك في اتخاذ القرار', 'users', true, 4),
  ('التقييم العقاري', 'تقييم دقيق لقيمة عقارك بناءً على معايير السوق', 'calculator', true, 5),
  ('إدارة الممتلكات', 'إدارة شاملة لممتلكاتك العقارية نيابة عنك', 'settings', true, 6)
ON CONFLICT DO NOTHING;

-- Enable RLS
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;

-- Public read for testimonials and services
CREATE POLICY "Testimonials viewable by everyone" ON testimonials
  FOR SELECT USING (is_active = true);

CREATE POLICY "Services viewable by everyone" ON services
  FOR SELECT USING (is_active = true);

-- Site settings public read for general settings
CREATE POLICY "Site settings viewable by everyone" ON site_settings
  FOR SELECT USING (true);

-- Admin full access policies
CREATE POLICY "Admins full access to properties" ON properties
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to inquiries" ON inquiries
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to faqs" ON faqs
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to admins" ON admins
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to site_settings" ON site_settings
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to activity_logs" ON activity_logs
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to testimonials" ON testimonials
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Admins full access to services" ON services
  FOR ALL USING (auth.role() = 'authenticated');

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_activity_logs_admin_id ON activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_site_settings_category ON site_settings(category);
CREATE INDEX IF NOT EXISTS idx_testimonials_order ON testimonials(order_index);
CREATE INDEX IF NOT EXISTS idx_services_order ON services(order_index);
