'use client';

import { motion } from 'framer-motion';
import SectionWrapper from '@/components/ui/SectionWrapper';

interface ApproachSectionProps {
  title: string;
  content: string;
}

export default function ApproachSection({ title, content }: ApproachSectionProps) {
  const parts = content.split('\n\n');
  const intro = parts[0];
  const steps = parts.slice(1).filter((p) => p.trim());
  
  return (
    <SectionWrapper className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-8 text-center"
        >
          {title}
        </motion.h2>
        
        {intro && (
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.08, ease: 'easeOut' }}
            className="text-lg text-gray-700 leading-relaxed mb-8 text-center"
          >
            {intro}
          </motion.p>
        )}
        
        <div className="space-y-4">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -12 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.15 + index * 0.08, ease: 'easeOut' }}
              className="flex gap-4"
            >
              <div className="flex-shrink-0 w-2 h-2 bg-green-600 rounded-full mt-2" />
              <p className="text-lg text-gray-700 leading-relaxed flex-1">
                {step}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </SectionWrapper>
  );
}
