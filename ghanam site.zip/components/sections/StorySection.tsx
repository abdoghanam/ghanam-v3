'use client';

import { motion } from 'framer-motion';
import SectionWrapper from '@/components/ui/SectionWrapper';

interface StorySectionProps {
  title: string;
  content: string;
}

export default function StorySection({ title, content }: StorySectionProps) {
  const paragraphs = content.split('\n\n').filter((p) => p.trim());
  
  return (
    <SectionWrapper className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-8 text-center"
        >
          {title}
        </motion.h2>
        
        <div className="space-y-6">
          {paragraphs.map((paragraph, index) => (
            <motion.p
              key={index}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08, ease: 'easeOut' }}
              className="text-lg text-gray-700 leading-relaxed"
            >
              {paragraph}
            </motion.p>
          ))}
        </div>
      </div>
    </SectionWrapper>
  );
}
