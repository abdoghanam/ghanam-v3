'use client';

import { motion } from 'framer-motion';
import CTA from '@/components/ui/CTA';

interface HeroSectionProps {
  title: string;
  subtitle: string;
  cta: {
    text: string;
    href: string;
  };
}

export default function HeroSection({ title, subtitle, cta }: HeroSectionProps) {
  const lines = subtitle.split('\n');
  
  return (
    <section className="relative min-h-[85vh] flex flex-col justify-center items-center text-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
          className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6"
        >
          {title}
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.12, ease: 'easeOut' }}
          className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          {lines.map((line, index) => (
            <span key={index}>
              {line}
              {index < lines.length - 1 && <br />}
            </span>
          ))}
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.24, ease: 'easeOut' }}
        >
          <CTA
            text={cta.text}
            href={cta.href}
            variant="primary"
            size="lg"
            className="inline-block"
          />
        </motion.div>
      </div>
    </section>
  );
}
