'use client';

import { motion } from 'framer-motion';
import SectionWrapper from '@/components/ui/SectionWrapper';

interface ValuePropositionSectionProps {
  title: string;
  content: string;
}

export default function ValuePropositionSection({
  title,
  content,
}: ValuePropositionSectionProps) {
  const lines = content.split('\n');
  
  return (
    <SectionWrapper className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-4xl mx-auto text-center">
        <motion.h2
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6"
        >
          {title}
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.08, ease: 'easeOut' }}
          className="text-lg text-gray-600 leading-relaxed max-w-2xl mx-auto whitespace-pre-line"
        >
          {content}
        </motion.p>
      </div>
    </SectionWrapper>
  );
}
