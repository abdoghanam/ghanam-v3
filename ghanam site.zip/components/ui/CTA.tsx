import { motion } from 'framer-motion';
import Button from './Button';

interface CTAProps {
  text: string;
  href: string;
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export default function CTA({
  text,
  href,
  variant = 'primary',
  size = 'lg',
  className = '',
}: CTAProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.25, delay: 0.1, ease: 'easeOut' }}
      className={className}
    >
      <Button
        href={href}
        variant={variant}
        size={size}
        ariaLabel={text}
      >
        <span>{text}</span>
        <svg
          className="w-5 h-5 -scale-x-100"
          fill="currentColor"
          viewBox="0 0 20 20"
          aria-hidden="true"
        >
          <path
            fillRule="evenodd"
            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
            clipRule="evenodd"
          />
        </svg>
      </Button>
    </motion.div>
  );
}
