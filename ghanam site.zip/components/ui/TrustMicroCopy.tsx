'use client';

import { motion } from 'framer-motion';

interface TrustMicroCopyProps {
  text: string;
  className?: string;
}

export default function TrustMicroCopy({ text, className = '' }: TrustMicroCopyProps) {
  return (
    <motion.p
      initial={{ opacity: 0, y: 6 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className={`text-center text-gray-600 text-base leading-relaxed max-w-2xl mx-auto px-4 ${className}`}
    >
      {text}
    </motion.p>
  );
}
