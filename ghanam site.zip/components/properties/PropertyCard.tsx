'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { formatPrice, formatWhatsAppURL } from '@/lib/utils/format';
import type { Property } from '@/types/properties';
import CTA from '@/components/ui/CTA';

interface PropertyCardProps {
  property: Property;
  index?: number;
}

const typeLabels: Record<string, string> = {
  apartment: 'شقة',
  villa: 'فيلا',
  land: 'أرض',
  commercial: 'تجاري',
  other: 'أخرى',
};

export default function PropertyCard({ property, index = 0 }: PropertyCardProps) {
  const mainImage = property.images[0] || {
    url: '/images/placeholder.jpg',
    alt: property.title,
    order: 1,
  };
  
  const whatsappURL = formatWhatsAppURL(
    property.whatsapp,
    `مرحباً، أنا مهتم بالعقار: ${property.title}`
  );
  
  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.08, ease: 'easeOut' }}
      className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
    >
      <Link href={`/properties/${property.slug}`} className="block">
        <div className="relative w-full h-48 bg-gray-200">
          {mainImage.url && (
            <Image
              src={mainImage.url}
              alt={mainImage.alt}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
          )}
          {property.featured && (
            <div className="absolute top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded">
              مميز
            </div>
          )}
          <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
            {typeLabels[property.type] || property.type}
          </div>
        </div>
      </Link>
      
      <div className="p-6">
        <Link href={`/properties/${property.slug}`}>
          <h3 className="text-xl font-semibold text-gray-900 mb-2 hover:text-green-600 transition-colors">
            {property.title}
          </h3>
        </Link>
        
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
            />
          </svg>
          <span>{property.location.district}</span>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="text-2xl font-bold text-gray-900">
            {formatPrice(property.price, property.currency)}
          </div>
          <div className="text-sm text-gray-600">
            {property.specs.size} {property.specs.sizeUnit}
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
          <span>{property.specs.rooms} غرف</span>
          <span>{property.specs.bathrooms} حمام</span>
          <span>الطابق {property.specs.floor}</span>
        </div>
        
        <CTA
          text="تواصل عبر واتساب"
          href={whatsappURL}
          variant="primary"
          size="md"
          className="w-full"
        />
      </div>
    </motion.article>
  );
}
