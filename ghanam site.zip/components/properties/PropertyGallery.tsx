'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import type { PropertyImage } from '@/types/properties';

interface PropertyGalleryProps {
  images: PropertyImage[];
  title: string;
}

export default function PropertyGallery({ images, title }: PropertyGalleryProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  
  if (images.length === 0) {
    return (
      <div className="w-full h-96 bg-gray-200 rounded-lg flex items-center justify-center">
        <p className="text-gray-500">لا توجد صور متاحة</p>
      </div>
    );
  }
  
  const sortedImages = [...images].sort((a, b) => a.order - b.order);
  const mainImage = sortedImages[selectedIndex] || sortedImages[0];
  
  return (
    <div className="space-y-4">
      <div className="relative w-full h-96 bg-gray-200 rounded-lg overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="relative w-full h-full"
          >
            <Image
              src={mainImage.url}
              alt={mainImage.alt || title}
              fill
              className="object-cover"
              sizes="100vw"
              priority
            />
          </motion.div>
        </AnimatePresence>
      </div>
      
      {sortedImages.length > 1 && (
        <div className="grid grid-cols-4 gap-2">
          {sortedImages.map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedIndex(index)}
              className={`relative w-full h-20 bg-gray-200 rounded overflow-hidden ${
                selectedIndex === index ? 'ring-2 ring-green-600' : ''
              }`}
            >
              <Image
                src={image.url}
                alt={image.alt || `${title} - صورة ${index + 1}`}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 25vw, 25vw"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
