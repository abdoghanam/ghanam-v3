'use client';

import { motion } from 'framer-motion';
import type { PropertySpecs } from '@/types/properties';

interface PropertySpecsProps {
  specs: PropertySpecs;
}

const specLabels: Record<string, string> = {
  size: 'المساحة',
  rooms: 'الغرف',
  bathrooms: 'الحمامات',
  floor: 'الطابق',
  totalFloors: 'عدد الطوابق',
  age: 'العمر',
  furnished: 'التشطيب',
};

export default function PropertySpecs({ specs }: PropertySpecsProps) {
  const specItems = [
    { label: specLabels.size, value: `${specs.size} ${specs.sizeUnit}` },
    { label: specLabels.rooms, value: `${specs.rooms} غرفة` },
    { label: specLabels.bathrooms, value: `${specs.bathrooms} حمام` },
    { label: specLabels.floor, value: `الطابق ${specs.floor} من ${specs.totalFloors}` },
    { label: specLabels.age, value: `${specs.age} سنة` },
    { label: specLabels.furnished, value: specs.furnished ? 'مفروش' : 'غير مفروش' },
  ];
  
  return (
    <div className="bg-gray-50 rounded-lg p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">المواصفات</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {specItems.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -12 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.25, delay: index * 0.04, ease: 'easeOut' }}
            className="flex justify-between items-center py-2 border-b border-gray-200 last:border-0"
          >
            <span className="text-gray-600">{item.label}</span>
            <span className="font-semibold text-gray-900">{item.value}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
