import { loadPublishedProperties } from '@/lib/data/loaders';
import { loadPagesData } from '@/lib/data/loaders';
import type { MetadataRoute } from 'next';

export const dynamic = 'force-static';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ghanam-realestate.com';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const properties = await loadPublishedProperties();
  const pages = await loadPagesData();

  const routes: MetadataRoute.Sitemap = [
    {
      url: siteUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${siteUrl}/properties`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: `${siteUrl}/about`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.8,
    },
  ];

  properties.forEach((property) => {
    routes.push({
      url: `${siteUrl}/properties/${property.slug}`,
      lastModified: new Date(property.updatedAt),
      changeFrequency: 'weekly',
      priority: 0.7,
    });
  });

  pages.forEach((page) => {
    routes.push({
      url: `${siteUrl}/${page.slug}`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.6,
    });
  });

  return routes;
}
