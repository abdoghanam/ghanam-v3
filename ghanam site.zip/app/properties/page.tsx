import { loadPublishedProperties } from '@/lib/data/loaders';
import PropertiesGrid from '@/components/properties/PropertiesGrid';
import PageHeader from '@/components/sections/PageHeader';
import { generateMetadata as generateSEOMetadata } from '@/lib/utils/seo';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateSEOMetadata({
    title: 'العقارات المتاحة',
    description: 'تصفح جميع العقارات المتاحة للبيع في المحلة الكبرى. شقق، فيلات، أراضي، وعقارات تجارية.',
    url: '/properties',
  });
}

export default async function PropertiesPage() {
  const properties = await loadPublishedProperties();
  
  return (
    <>
      <PageHeader
        title="العقارات المتاحة"
        description={`${properties.length} عقار متاح للبيع`}
      />
      
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <PropertiesGrid properties={properties} />
        </div>
      </section>
    </>
  );
}
