import { loadPropertyBySlug, loadPublishedProperties } from '@/lib/data/loaders';
import { notFound } from 'next/navigation';
import PropertyGallery from '@/components/properties/PropertyGallery';
import PropertySpecs from '@/components/properties/PropertySpecs';
import CTA from '@/components/ui/CTA';
import SectionWrapper from '@/components/ui/SectionWrapper';
import { formatPrice, formatWhatsAppURL } from '@/lib/utils/format';
import { generateMetadata as generateSEOMetadata, generatePropertyStructuredData, generateBreadcrumbStructuredData } from '@/lib/utils/seo';
import type { Metadata } from 'next';
import type { Property } from '@/types/properties';

const typeLabels: Record<string, string> = {
  apartment: 'شقة',
  villa: 'فيلا',
  land: 'أرض',
  commercial: 'تجاري',
  other: 'أخرى',
};

export async function generateStaticParams() {
  const properties = await loadPublishedProperties();
  return properties.map((property) => ({
    slug: property.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const property = await loadPropertyBySlug(slug);
  
  if (!property) {
    return {
      title: 'عقار غير موجود - غنّام للعقارات',
    };
  }
  
  const image = property.images[0]?.url || '/images/og-image.jpg';
  
  return generateSEOMetadata({
    title: property.seo.title,
    description: property.seo.description,
    image,
    url: `/properties/${property.slug}`,
    type: 'article',
  });
}

export default async function PropertyDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const property = await loadPropertyBySlug(slug);
  
  if (!property) {
    notFound();
  }
  
  const whatsappURL = formatWhatsAppURL(
    property.whatsapp,
    `مرحباً، أنا مهتم بالعقار: ${property.title}`
  );
  
  const propertyStructuredData = generatePropertyStructuredData(property);
  const breadcrumbData = generateBreadcrumbStructuredData([
    { name: 'الرئيسية', url: '/' },
    { name: 'العقارات', url: '/properties' },
    { name: property.title, url: `/properties/${property.slug}` },
  ]);
  
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(propertyStructuredData) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbData) }}
      />
      <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <span className="text-sm text-gray-600">
              {typeLabels[property.type] || property.type}
            </span>
            {property.featured && (
              <span className="mr-2 text-sm bg-green-600 text-white px-2 py-1 rounded">
                مميز
              </span>
            )}
          </div>
          
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {property.title}
          </h1>
          
          <div className="flex items-center gap-4 text-gray-600 mb-6">
            <div className="flex items-center gap-1">
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
              <span>{property.location.district}، {property.location.city}</span>
            </div>
          </div>
          
          <div className="text-3xl font-bold text-gray-900 mb-8">
            {formatPrice(property.price, property.currency)}
          </div>
        </div>
      </SectionWrapper>
      
      <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <PropertyGallery images={property.images} title={property.title} />
        </div>
      </SectionWrapper>
      
      <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <PropertySpecs specs={property.specs} />
        </div>
      </SectionWrapper>
      
      {property.description && (
        <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">الوصف</h2>
            <p className="text-lg text-gray-700 leading-relaxed whitespace-pre-line">
              {property.description}
            </p>
          </div>
        </SectionWrapper>
      )}
      
      {property.features.length > 0 && (
        <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">المميزات</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {property.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-600 rounded-full" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      )}
      
      <SectionWrapper className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            مهتم بهذا العقار؟
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            تواصل معنا الآن للحصول على مزيد من المعلومات
          </p>
          <CTA
            text="تواصل عبر واتساب"
            href={whatsappURL}
            variant="primary"
            size="lg"
            className="inline-block"
          />
        </div>
      </SectionWrapper>
    </>
  );
}
