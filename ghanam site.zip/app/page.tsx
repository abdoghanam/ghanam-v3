import { loadHomeData } from '@/lib/data/loaders';
import HeroSection from '@/components/sections/HeroSection';
import ValuePropositionSection from '@/components/sections/ValuePropositionSection';
import ServicesOverviewSection from '@/components/sections/ServicesOverviewSection';
import CTASection from '@/components/sections/CTASection';
import TrustMicroCopy from '@/components/ui/TrustMicroCopy';
import { generateMetadata as generateSEOMetadata } from '@/lib/utils/seo';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  const homeData = await loadHomeData();
  return generateSEOMetadata({
    title: homeData.hero.title,
    description: 'عقارات للبيع والشراء في المحلة الكبرى – مصر. فرص عقارية حقيقية بعقل السوق.',
    url: '/',
  });
}

export default async function HomePage() {
  const homeData = await loadHomeData();

  return (
    <>
      <HeroSection
        title={homeData.hero.title}
        subtitle={homeData.hero.subtitle}
        cta={homeData.hero.cta}
      />
      
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <TrustMicroCopy text="نعرف السوق من جوا، وبنقولك الحقيقة كما هي." />
      </div>
      
      <ValuePropositionSection
        title={homeData.valueProposition.title}
        content={homeData.valueProposition.content}
      />
      
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <TrustMicroCopy text="كل عقار هنا مرشح بعناية، وكل تفصيلة واضحة من الأول." />
      </div>
      
      <ServicesOverviewSection
        title={homeData.services.title}
        items={homeData.services.items}
      />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-900">
        <TrustMicroCopy text="نستمع أولاً، ثم نرشح ما يناسبك فعلاً." className="text-gray-300" />
      </div>
      
      <CTASection
        title={homeData.cta.title}
        subtitle={homeData.cta.subtitle}
        button={homeData.cta.button}
      />
    </>
  );
}
