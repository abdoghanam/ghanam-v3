import { loadPageBySlug } from '@/lib/data/loaders';
import { notFound } from 'next/navigation';
import PageHeader from '@/components/sections/PageHeader';
import StorySection from '@/components/sections/StorySection';
import ValuesSection from '@/components/sections/ValuesSection';
import ApproachSection from '@/components/sections/ApproachSection';
import CTASection from '@/components/sections/CTASection';
import { generateMetadata as generateSEOMetadata } from '@/lib/utils/seo';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  const pageData = await loadPageBySlug('about');
  
  if (!pageData) {
    return {
      title: 'من نحن - غنّام للعقارات',
    };
  }
  
  return generateSEOMetadata({
    title: pageData.seo.title,
    description: pageData.seo.description,
    url: '/about',
  });
}

export default async function AboutPage() {
  const pageData = await loadPageBySlug('about');
  
  if (!pageData) {
    notFound();
  }
  
  const storySection = pageData.sections.find((s) => s.type === 'story');
  const valuesSection = pageData.sections.find((s) => s.type === 'values');
  const approachSection = pageData.sections.find((s) => s.type === 'approach');
  
  return (
    <>
      <PageHeader title={pageData.title} description={pageData.description} />
      
      {storySection && storySection.content && (
        <StorySection
          title={storySection.title}
          content={storySection.content}
        />
      )}
      
      {valuesSection && valuesSection.items && (
        <ValuesSection
          title={valuesSection.title}
          items={valuesSection.items}
        />
      )}
      
      {approachSection && approachSection.content && (
        <ApproachSection
          title={approachSection.title}
          content={approachSection.content}
        />
      )}
      
      <CTASection
        title="مستعد تبدأ؟"
        subtitle="تواصل معنا الآن واحصل على استشارة مجانية"
        button={{
          text: 'تواصل عبر واتساب',
          href: 'https://wa.me/201011244308',
        }}
      />
    </>
  );
}
