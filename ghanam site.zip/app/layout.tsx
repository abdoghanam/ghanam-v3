import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { loadSettings } from "@/lib/data/loaders";
import { generateOrganizationStructuredData } from "@/lib/utils/seo";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-cairo",
  display: "swap",
  preload: true,
});

export async function generateMetadata(): Promise<Metadata> {
  const settings = await loadSettings();
  const siteName = settings?.site?.name || "غنّام للعقارات";
  const description = settings?.site?.description || "عقارات للبيع والشراء في المحلة الكبرى – مصر";
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://ghanam-realestate.com";
  const ogImage = settings?.seo?.ogImage || `${siteUrl}/images/og-image.jpg`;

  return {
    metadataBase: new URL(siteUrl),
    title: {
      default: siteName,
      template: `%s | ${siteName}`,
    },
    description,
    keywords: ["عقارات", "المحلة الكبرى", "شقق للبيع", "فيلا للبيع", "أراضي للبيع", "مصر"],
    authors: [{ name: siteName }],
    creator: siteName,
    publisher: siteName,
    formatDetection: {
      email: false,
      address: false,
      telephone: false,
    },
    alternates: {
      canonical: siteUrl,
      languages: {
        "ar-EG": siteUrl,
        "ar": siteUrl,
      },
    },
    openGraph: {
      type: "website",
      locale: "ar_EG",
      url: siteUrl,
      siteName,
      title: siteName,
      description,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: siteName,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: siteName,
      description,
      images: [ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
    verification: {
      google: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION,
    },
    other: {
      "geo.region": "EG-GH",
      "geo.placename": "المحلة الكبرى",
      "geo.position": "30.9697;31.1667",
      "ICBM": "30.9697, 31.1667",
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const organizationData = generateOrganizationStructuredData();

  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />
        <meta name="theme-color" content="#ffffff" />
        <meta name="format-detection" content="telephone=no" />
        <link rel="canonical" href={process.env.NEXT_PUBLIC_SITE_URL || "https://ghanam-realestate.com"} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationData) }}
        />
      </head>
      <body className="min-h-screen bg-white text-gray-900 antialiased">
        <div className="flex min-h-screen flex-col">
          <header className="border-b border-gray-200">
            <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="flex h-16 items-center justify-between">
                <h1 className="text-lg font-semibold">غنّام للعقارات</h1>
                <a
                  href="https://wa.me/201011244308"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition-colors hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2"
                  aria-label="تواصل معنا على واتساب"
                >
                  واتساب
                </a>
              </div>
            </div>
          </header>

          <main className="flex-1">{children}</main>

          <footer className="border-t border-gray-200">
            <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
              <p className="text-center text-sm text-gray-600">
                المحلة الكبرى – مصر
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
