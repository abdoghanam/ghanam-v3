import type { Metadata } from 'next';
import type { Property } from '@/types/properties';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ghanam-realestate.com';

export function generateMetadata({
  title,
  description,
  image,
  url,
  type = 'website',
}: {
  title: string;
  description: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article';
}): Metadata {
  const fullTitle = title.includes('غنّام') ? title : `${title} | غنّام للعقارات`;
  const fullUrl = url ? `${siteUrl}${url}` : siteUrl;
  const ogImage = image || `${siteUrl}/images/og-image.jpg`;

  return {
    title: fullTitle,
    description,
    alternates: {
      canonical: fullUrl,
    },
    openGraph: {
      title: fullTitle,
      description,
      url: fullUrl,
      siteName: 'غنّام للعقارات',
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      locale: 'ar_EG',
      type,
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
    verification: {
      google: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION,
    },
  };
}

export function generatePropertyStructuredData(property: Property) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ghanam-realestate.com';
  const imageUrl = property.images[0]?.url 
    ? (property.images[0].url.startsWith('http') ? property.images[0].url : `${siteUrl}${property.images[0].url}`)
    : `${siteUrl}/images/og-image.jpg`;

  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateListing',
    name: property.title,
    description: property.description,
    image: imageUrl,
    url: `${siteUrl}/properties/${property.slug}`,
    address: {
      '@type': 'PostalAddress',
      addressLocality: property.location.city,
      addressRegion: property.location.district,
      streetAddress: property.location.address,
      addressCountry: 'EG',
    },
    offers: {
      '@type': 'Offer',
      price: property.price,
      priceCurrency: property.currency,
      availability: property.status === 'available' ? 'https://schema.org/InStock' : 'https://schema.org/SoldOut',
    },
    floorSize: {
      '@type': 'QuantitativeValue',
      value: property.specs.size,
      unitCode: 'MTK',
    },
    numberOfRooms: property.specs.rooms,
    numberOfBathroomsTotal: property.specs.bathrooms,
  };
}

export function generateOrganizationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateAgent',
    name: 'غنّام للعقارات',
    description: 'عقارات للبيع والشراء في المحلة الكبرى – مصر',
    url: siteUrl,
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'المحلة الكبرى',
      addressRegion: 'الغربية',
      addressCountry: 'EG',
    },
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+20-101-124-4308',
      contactType: 'customer service',
      availableLanguage: 'Arabic',
    },
  };
}

export function generateBreadcrumbStructuredData(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: `${siteUrl}${item.url}`,
    })),
  };
}
