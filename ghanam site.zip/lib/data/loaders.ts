import { promises as fs } from 'fs';
import path from 'path';
import type { HomeData } from '@/types/home';
import type { PagesData, PageData } from '@/types/pages';
import type { PropertiesData, Property } from '@/types/properties';

const dataDirectory = path.join(process.cwd(), 'data');

export async function loadHomeData(): Promise<HomeData> {
  const filePath = path.join(dataDirectory, 'home.json');
  const fileContents = await fs.readFile(filePath, 'utf8');
  return JSON.parse(fileContents) as HomeData;
}

export async function loadPagesData(): Promise<PagesData> {
  const filePath = path.join(dataDirectory, 'pages.json');
  const fileContents = await fs.readFile(filePath, 'utf8');
  return JSON.parse(fileContents) as PagesData;
}

export async function loadPageBySlug(slug: string): Promise<PageData | null> {
  const pages = await loadPagesData();
  return pages.find((page) => page.slug === slug) || null;
}

export async function loadPropertiesData(): Promise<PropertiesData> {
  const filePath = path.join(dataDirectory, 'properties.json');
  const fileContents = await fs.readFile(filePath, 'utf8');
  return JSON.parse(fileContents) as PropertiesData;
}

export async function loadPublishedProperties(): Promise<Property[]> {
  const properties = await loadPropertiesData();
  return properties.filter((prop) => prop.published);
}

export async function loadPropertyBySlug(slug: string): Promise<Property | null> {
  const properties = await loadPropertiesData();
  return properties.find((prop) => prop.slug === slug && prop.published) || null;
}

export async function loadFeaturedProperties(): Promise<Property[]> {
  const properties = await loadPublishedProperties();
  return properties.filter((prop) => prop.featured);
}

export async function loadSettings() {
  try {
    const filePath = path.join(dataDirectory, 'settings.json');
    const fileContents = await fs.readFile(filePath, 'utf8');
    return JSON.parse(fileContents);
  } catch {
    return null;
  }
}
