This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
You are acting as a Senior Next.js Architect.

GOAL:
Prepare a clean, production-grade foundation for a static real estate website using Next.js App Router.

STRICT RULES:
- Static Generation ONLY (no SSR, no APIs)
- Arabic RTL first
- Performance-first
- Clean, minimal, professional
- No mock designs, no heavy visuals yet

TECH:
- Next.js App Router
- TypeScript
- Tailwind CSS
- Framer Motion (installed, not used yet)
- Three.js / React Three Fiber (installed, not used yet)
- Decap CMS ready (no config yet)

TASKS:

1. Clean the default Next.js boilerplate
   - Remove demo content
   - Keep only essentials

2. Create the following folder structure:

/src
  /app
    layout.tsx
    page.tsx
    globals.css
  /components
    SectionWrapper.tsx
    CTA.tsx
  /data
    settings.json
    pages.json
    properties.json
  /lib
  /styles
/admin
/public/images

3. Configure:
   - RTL support globally
   - Arabic font (Google Font – Cairo or Tajawal)
   - Tailwind base setup
   - Clean layout.tsx with <html dir="rtl" lang="ar">

4. Create minimal placeholder content:
   - Home page with Arabic placeholder text
   - No design, just structure

5. Ensure:
   - Project builds without errors
   - No unused code
   - No console warnings

DO NOT:
- Add business logic
- Add CMS config
- Add animations
- Add 3D scenes
- Add branding yet

FINAL CHECK:
Project must feel clean, calm, and ready for professional expansion.


## Project Setup Checklist

### 1. Clean Boilerplate & Keep Essentials

- **[x]** Remove all demo/sample code files and content.
- **[x]** Retain only the minimum required files for the Next.js project to run.

---

### 2. Folder Structure

```
/src
  /app
    layout.tsx            ← Root layout with RTL & Arabic (Cairo or Tajawal)
    page.tsx              ← Minimal Arabic placeholder home page
    globals.css           ← Imports font, Tailwind base, sets global direction
  /components
    SectionWrapper.tsx    ← Placeholder export (empty or minimal)
    CTA.tsx               ← Placeholder export (empty or minimal)
  /data
    settings.json         ← {}
    pages.json            ← []
    properties.json       ← []
  /lib/                   ← (empty)
  /styles/                ← (empty)
/admin/                   ← (empty)
/public/images/           ← (empty, for future assets)
```

---

### 3. Configuration

- **RTL Support:**  
  - Global directionality with `<html dir="rtl" lang="ar">`
  - Tailwind `dir="rtl"` enabled (in `tailwind.config.js` with RTL plugin if used)

- **Arabic Font:**  
  - Use Google Fonts "Cairo" or "Tajawal" (recommended: *Cairo*)
  - Import font in `globals.css` and apply via `font-family` and/or Tailwind custom font class

- **Tailwind CSS:**  
  - Minimal Tailwind setup, jit enabled, purge paths set only to `/src`
  - Custom font family set if needed

---

### 4. Minimal Placeholder Content

- **Home page** (`/src/app/page.tsx`):  
  ```
  مرحبًا بك في الموقع العقاري التجريبي.
  سيتم إضافة المحتوى قريبًا.
  ```

- **No design yet:**  
  No colors, no images, no branding, no layout, no interactivity.

---

### 5. Quality Checklist

- No SSR, API, or business logic code (pure SSG).
- No unused imports, demo, or placeholder code left.
- All placeholder files and directories exist (but are empty if not used yet).
- Project builds cleanly (no warnings, errors, or unused file warnings).

---

**Ready for professional expansion and minimal, calm hand-off.**

**Project Foundation Checklist**

---

**Production Foundation Overview**

---

### 1. Project Structure

```
/src
  /app
    layout.tsx
    page.tsx
    globals.css
  /components
    SectionWrapper.tsx
    CTA.tsx
  /data
    settings.json
    pages.json
    properties.json
  /lib/
  /styles/
```

- `/admin/` – for Decap CMS (empty, config to be added later)
- `/public/images/` – for future assets

---

### 2. Global Configuration

- **RTL & Arabic:**  
  - Use `<html dir="rtl" lang="ar">` in `layout.tsx`
  - Tailwind is configured to support RTL (RTL plugin if needed)

- **Typography:**  
  - Use Google Fonts "Cairo" (import via `globals.css`)
  - Apply as default font in Tailwind config and via base styles

- **Tailwind CSS:**  
  - Minimal config for performance and purge
  - Only `/src` files scanned

---

### 3. Placeholder Content

- **Home page (`/src/app/page.tsx`):**

  ```
  مرحبًا بك في الموقع العقاري التجريبي.
  سيتم إضافة المحتوى قريبًا.
  ```

- No design, branding, layout, or interactivity yet.

---

### 4. Quality Gates

- Pure Static Generation (no SSR, no APIs, no business logic)
- No demo or placeholder code left from Next.js boilerplate
- No unused files or imports
- Clean build; no warnings or errors
- Ready for professional expansion

---