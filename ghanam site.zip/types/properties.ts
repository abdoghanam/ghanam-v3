export type PropertyType = 'apartment' | 'villa' | 'land' | 'commercial' | 'other';
export type PropertyStatus = 'available' | 'sold' | 'reserved';
export type Currency = 'EGP' | 'USD';

export interface PropertyImage {
  url: string;
  alt: string;
  order: number;
}

export interface PropertyLocation {
  city: string;
  district: string;
  address: string;
}

export interface PropertySpecs {
  size: number;
  sizeUnit: string;
  rooms: number;
  bathrooms: number;
  floor: number;
  totalFloors: number;
  age: number;
  furnished: boolean;
}

export interface PropertySEO {
  title: string;
  description: string;
}

export interface Property {
  id: string;
  slug: string;
  title: string;
  type: PropertyType;
  status: PropertyStatus;
  price: number;
  currency: Currency;
  location: PropertyLocation;
  specs: PropertySpecs;
  description: string;
  features: string[];
  images: PropertyImage[];
  whatsapp: string;
  published: boolean;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
  seo: PropertySEO;
}

export type PropertiesData = Property[];
