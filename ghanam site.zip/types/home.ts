export interface HomeData {
  hero: {
    title: string;
    subtitle: string;
    cta: {
      text: string;
      href: string;
    };
  };
  valueProposition: {
    title: string;
    content: string;
  };
  services: {
    title: string;
    items: Array<{
      id: string;
      title: string;
      description: string;
      icon: string;
    }>;
  };
  cta: {
    title: string;
    subtitle: string;
    button: {
      text: string;
      href: string;
    };
  };
}
