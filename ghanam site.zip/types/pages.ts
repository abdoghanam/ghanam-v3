export interface PageSection {
  type: string;
  title: string;
  content?: string;
  items?: Array<{
    title: string;
    description: string;
  }>;
}

export interface PageData {
  slug: string;
  title: string;
  description: string;
  sections: PageSection[];
  seo: {
    title: string;
    description: string;
  };
}

export interface PagesData extends Array<PageData> {}
